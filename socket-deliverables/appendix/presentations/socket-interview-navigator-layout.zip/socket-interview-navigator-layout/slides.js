window.SLIDES = [
 {
  "title": "First Login and Organization Access",
  "short": "Organization Access",
  "kicker": "",
  "lead": "",
  "points": [],
  "notes": [
   "This was a firsthand login observation. No screenshot was captured. The cause of the missing invitation and setup prompt remains unknown.",
   "Organization access worked later on November 16 and was confirmed on November 18. The practical risk was creating or configuring the wrong organization.",
   "Use a new hire’s first successful login as a checkpoint. Ask them to demonstrate how they verified identity, organization, entitlements, and repository access.",
   "Teach the two first-login paths in documentation. In onboarding and mentoring, rehearse an ambiguous prompt and have the learner explain when to pause and ask for help."
  ],
  "qa": [
   {
    "q": "Was the invitation broken?",
    "a": "I couldn’t establish that. I observed a missing invitation and an ambiguous setup screen. Access was confirmed later."
   }
  ],
  "sources": [
   "socket-deliverables/friction-log.md"
  ],
  "section": 0,
  "links": [],
  "panels": [
   {
    "label": "Expected experience",
    "text": "Accept the Enterprise invitation and join the provisioned organization."
   },
   {
    "label": "Observed experience",
    "text": "GitHub authentication succeeded. The invitation was missing from the inbox search, and the organization setup screen left the next step unclear."
   },
   {
    "label": "Resolution",
    "text": "Paused before creating an organization and asked recruiting to confirm the intended access path. Access worked later."
   },
   {
    "label": "Proposed onboarding improvements",
    "items": [
     "Separate guidance for invited users and new organization creators.",
     "Verify identity, membership, entitlements, and repository access before exercises.",
     "Document a troubleshooting path for missing invitations."
    ]
   }
  ]
 },
 {
  "title": "CLI Permissions and Least Privilege",
  "short": "CLI Permissions",
  "kicker": "",
  "lead": "The permissions were documented, but assembling them into a complete workflow required consulting multiple references.",
  "points": [],
  "notes": [
   "The initial local CLI create-and-report flow succeeded with these three scopes. The friction was discovering the complete workflow across references.",
   "The Permissions Explorer organizes 68 documented commands and variants by role and task. Pick a workflow and show Scopes to tick. Use an editable copy if the shared master is comment-only. Verify untested API paths separately.",
   "Separate CLI operation, organization policy settings in the web app, CI credentials, GitHub App access, and Firewall authorization. They answer different questions and use different authorization paths.",
   "Ask the learner to identify the minimum scopes, execute the task, and explain what evidence establishes success.",
   "The bundled friction log also records duplicate App and Actions feedback, wording on token rotation, Package Scores explainability, and Firewall preflight. These documentation improvements are proposals."
  ],
  "qa": [
   {
    "q": "Would the same token work for CI?",
    "a": "The local workflow establishes what those three scopes cover. CI used a separate credential. The preferred CI comparison still encountered a permission denial."
   },
   {
    "q": "What would you test with a new hire?",
    "a": "Give them a goal and ask them to identify the minimum scopes, create a scan, and show its policy result without prompting."
   }
  ],
  "sources": [
   "socket-deliverables/appendix/permissions-explorer",
   "socket-deliverables/friction-log.md",
   "socket-deliverables/part-i-briefing.md",
   "research/planning/cli-permissions-worksheet-handoff.md",
   "socket-deliverables/integration-comparison.md",
   "socket-deliverables/appendix/package-scores-rewrite.md",
   "socket-deliverables/part-ii-firewall-results.md"
  ],
  "section": 0,
  "links": [],
  "matrix": {
   "label": "Verified local CLI permissions",
   "columns": [
    "Task",
    "Required scope"
   ],
   "rows": [
    [
     "Create a scan",
     "full-scans:create"
    ],
    [
     "Inspect scan results",
     "full-scans:list"
    ],
    [
     "Evaluate security policy",
     "security-policy:read"
    ]
   ],
   "scope": "The create-and-report workflow needs all three scopes. The report operation needs both full-scans:list and security-policy:read."
  },
  "stepLabel": "Proposed improvement · Socket CLI Permissions Explorer",
  "steps": [
   "Select a task",
   "Identify required scopes",
   "Configure a least-privilege token",
   "Verify the result"
  ]
 },
 {
  "title": "Setup and first scan",
  "short": "Establishing baseline",
  "kicker": "Part I · Getting familiar with Socket",
  "lead": "ActivityPulse gave the scan a real change to detect. Adding YAML input introduced PyYAML 6.0.2.",
  "points": [
   {
    "label": "Baseline",
    "text": "The Node CLI and Python reporter processed 117 CSV records. The first scan, before external dependencies, was healthy with zero alert records."
   },
   {
    "label": "Change",
    "text": "Adding PyYAML produced 53 records for release artifacts belonging to one package version."
   },
   {
    "label": "Interpretation",
    "text": "The package raised signals including potential vulnerability and native code. I checked how the app parsed YAML and how policy treated each signal."
   }
  ],
  "notes": [
   "Node prints the summary. Python reads CSV or YAML and groups the records by type.",
   "Show yaml.safe_load in the reporter. That choice matters when evaluating a concern about unsafe constructors. It cannot settle every other signal.",
   "Ask the panel what their first question would be if a learner called this 53 vulnerable dependencies.",
   "Potential vulnerability is a finding to investigate. The experiment did not establish exploitability in this application. A healthy status reflects the evaluated policy and can coexist with findings."
  ],
  "qa": [
   {
    "q": "Can a scan be healthy while it contains findings?",
    "a": "Yes. The initial PyYAML scan recorded signals and inherited Ignore actions. Scan health reflects the evaluated policy."
   }
  ],
  "sources": [
   "socket-deliverables/part-i-briefing.md",
   "socket-deliverables/part-i-walkthrough.md",
   "activitypulse/report.py"
  ],
  "section": 1,
  "links": []
 },
 {
  "title": "What engineers see under Block and Warn",
  "short": "Applying Policy",
  "kicker": "Part I · Getting familiar with Socket",
  "lead": "I kept the PyYAML finding and changed the organization’s action for the Potential vulnerability alert type.",
  "points": [
   {
    "label": "Block",
    "text": "A fresh scan was unhealthy. The combined create-and-report command exited 1."
   },
   {
    "label": "Warn",
    "text": "A second fresh scan was healthy and exited 0. The warning appeared at the warn report level."
   },
   {
    "label": "Restore",
    "text": "I returned the override to Inherit. The evidence ends with that confirmation."
   }
  ],
  "notes": [
   "Point to healthy: false, the alert type, and policy: error in the Block report. The original command’s exit code is recorded in the walkthrough. The historical capture shows prod/requirements.txt. The current repository places the manifest under activitypulse/.",
   "Open the Warn capture if asked. Its scan ID differs, its health is true, and the same package version carries policy: warn.",
   "A finding-specific resolution suits a reviewed exception. A rule changes the treatment of an alert class. This experiment used an organization-wide rule."
  ],
  "qa": [
   {
    "q": "Did changing the rule rewrite the old report?",
    "a": "The previously created scan retained its earlier evaluation when I inspected it. I created a new scan for each policy setting."
   },
   {
    "q": "Did you verify the restored state with another scan?",
    "a": "I confirmed the override returned to Inherit. I did not capture a third scan after restoring it."
   }
  ],
  "sources": [
   "socket-deliverables/part-i-briefing.md",
   "socket-deliverables/part-i-walkthrough.md",
   "socket-deliverables/images/part-iii/cli-policy-warn.png"
  ],
  "image": "socket-deliverables/images/part-iii/cli-policy-block.png",
  "imageAlt": "Captured PyYAML Block report showing healthy false and policy error.",
  "section": 1,
  "links": []
 },
 {
  "title": "Choosing a GitHub integration",
  "short": "Configure integration",
  "kicker": "Part I · Getting familiar with Socket",
  "lead": "Compare what the Socket GitHub App and GitHub Actions report to decide which fits the team’s workflow.",
  "points": [
   {
    "label": "GitHub App",
    "text": "The selected-repository installation posted a dependency overview and successful checks in the PR."
   },
   {
    "label": "GitHub Actions",
    "text": "Attempt 4 passed. The logs show that the preferred comparison hit a permission denial and the CLI completed a streaming comparison."
   },
   {
    "label": "Evaluation decision",
    "text": "I kept the App for routine PR feedback and removed the automatic PR trigger from the feature-branch workflow."
   }
  ],
  "notes": [
   "On the original PR, point out socket-security[bot] and github-actions[bot]. The two comments concern one dependency change.",
   "The earlier HTTP 401 cleared when the correct API token value was stored. The later comparison permission denial was a separate issue. Its exact cause remains open.",
   "The current feature branch retains a manual workflow. The captured run came from the earlier PR trigger. The manual workflow requires presence on the default branch for dispatch."
  ],
  "qa": [
   {
    "q": "Which integration would you teach first?",
    "a": "For someone learning scans and policy, start at the CLI. For a GitHub team that wants feedback in PRs, pilot the App on one repo. Use Actions when the customer needs a pipeline-owned check."
   },
   {
    "q": "Does a successful check enforce a merge gate?",
    "a": "I verified the check and comments. Merge enforcement also depends on repository rules and was outside this test."
   }
  ],
  "sources": [
   "socket-deliverables/integration-comparison.md",
   "socket-deliverables/part-i-briefing.md"
  ],
  "image": "socket-deliverables/images/part-iii/actions-compare-success.png",
  "imageAlt": "Successful GitHub Actions job with the comparison fallback highlighted in its logs.",
  "section": 1,
  "links": []
 },
 {
  "title": "The complete experiment",
  "short": "Full Experiment",
  "kicker": "Part I · Getting familiar with Socket",
  "lead": "",
  "points": [],
  "section": 1,
  "workflow": [
   {
    "label": "CLI · Scan 1",
    "text": "Healthy baseline with an empty dependency inventory"
   },
   {
    "label": "Local repository",
    "text": "Add PyYAML 6.0.2"
   },
   {
    "label": "CLI · Scan 2",
    "text": "Potential vulnerability detected under inherited Ignore"
   },
   {
    "label": "Socket web app",
    "text": "Set the alert policy to Block"
   },
   {
    "label": "CLI · Scan 3",
    "text": "Block · Unhealthy · Exit code 1"
   },
   {
    "label": "Socket web app",
    "text": "Set the same alert policy to Warn"
   },
   {
    "label": "CLI · Scan 4",
    "text": "Warn · Healthy · Exit code 0 · Warning visible in the report"
   },
   {
    "label": "Socket web app",
    "text": "Restore the policy to Inherit"
   }
  ],
  "notes": [
   "Step through the scan and policy changes from baseline to restore. The same PyYAML version was used for the policy comparison.",
   "The GitHub App and Actions comparison was a separate pull request experiment. Pause here for questions before Part II."
  ],
  "qa": [],
  "sources": [
   "socket-deliverables/part-i-briefing.md",
   "socket-deliverables/part-i-walkthrough.md",
   "socket-deliverables/integration-comparison.md"
  ],
  "links": []
 },
 {
  "title": "Setting up Socket Firewall",
  "short": "Setup and configuration",
  "kicker": "Part II · Socket Firewall",
  "lead": "We deployed Firewall in registry mode and configured an isolated npm client to route package downloads through it.",
  "points": [
   {
    "label": "Environment",
    "text": "Socket Firewall 2.23.0 ran in Docker through Colima on macOS."
   },
   {
    "label": "Configuration",
    "text": "A scoped API token, a trusted local TLS certificate, and an npm registry route on localhost:8443."
   },
   {
    "label": "Verification",
    "text": "Health returned HTTP 200. Startup logs confirmed the intended Socket organization."
   }
  ],
  "architecture": {
   "label": "Downstream registry mode",
   "route": [
    {
     "label": "npm client",
     "text": "Isolated test project"
    },
    {
     "label": "Socket Firewall",
     "text": "Docker via Colima · localhost:8443"
    },
    {
     "label": "Public npm registry",
     "text": "registry.npmjs.org"
    }
   ],
   "api": {
    "label": "Socket API",
    "text": "Security decisions and organization policy"
   }
  },
  "notes": [
   "Target 2:00. Restricted agent checks initially suggested prerequisites were unavailable. Direct host checks confirmed Colima and network access.",
   "A user-level bind to port 443 was denied. The demo used loopback port 8443 and trusted the local certificate through a scoped CA file, with TLS verification enabled.",
   "The rewritten tarball URL preserved the incoming hostname and port, which kept package downloads on the local Firewall route.",
   "The Firewall token was scoped to packages:list and entitlements:list. Keep its value off screen.",
   "Use the P01 capture to show service availability. Check the organization lookup separately. Each test used its own npm project and cache.",
   "Health confirms the service responds. Policy enforcement requires an actual registry request and decision."
  ],
  "qa": [
   {
    "q": "Does a healthy Firewall mean that developers are protected?",
    "a": "Health checks service availability. Verify the intended organization, package-manager routing through Firewall, and an enforced security decision."
   }
  ],
  "sources": [
   "socket-deliverables/images/part-ii/P01-startup-health.png",
   "socket-deliverables/part-ii-firewall-results.md",
   "socket-deliverables/part-ii-firewall-workplan.md",
   "socket-deliverables/friction-log.md",
   "socket-deliverables/appendix/socket-firewall-registry-mode-rewrite.md"
  ],
  "section": 2,
  "links": [
   {
    "title": "Socket dashboard · Settings → API Tokens",
    "url": "https://socket.dev/dashboard"
   },
   {
    "title": "Firewall registry setup guide",
    "url": "https://docs.socket.dev/docs/sfw-block-installs"
   },
   {
    "title": "Enterprise registry configuration",
    "url": "https://docs.socket.dev/docs/socket-firewall-enterprise-registry-mode-configuration-reference"
   }
  ]
 },
 {
  "title": "Applying policy at download time",
  "short": "Applying Policy",
  "kicker": "Part II · Socket Firewall",
  "lead": "Using the existing organization policy, we demonstrated two different outcomes through the same Firewall deployment.",
  "points": [],
  "comparison": [
   {
    "label": "Allowed installation",
    "package": "lodash@4.17.21",
    "http": "HTTP 200",
    "details": [
     "Decision: allowed · Action: monitor",
     "Medium CVE and High CVE alerts recorded",
     "npm installed the package"
    ],
    "tone": "allow"
   },
   {
    "label": "Blocked installation",
    "package": "lodahs@0.0.1-security",
    "http": "HTTP 403 · npm E403",
    "details": [
     "Decision: blocked · Reason: Known malware",
     "npm reported “Blocked by Security Policy”"
    ],
    "tone": "block"
   }
  ],
  "verification": {
   "label": "Separate HTTP verification",
   "results": [
    "Package metadata · HTTP 200",
    "Package tarball · HTTP 403"
   ],
   "correlation": "The original npm attempt and Firewall event matched on request ID 13c0…2f15."
  },
  "notes": [
   "Target 2:20. The organization policy remained unchanged. Both package download decisions were uncached.",
   "The allowed lodash download still recorded Medium CVE and High CVE alerts. Monitor was the applicable action.",
   "Known malware was the observed block reason for lodahs. Possible typosquat was a separate warning.",
   "The assignment specified the no-code lodahs fixture. Package scripts were disabled during the two npm tests.",
   "Point out the request_id, source_path, decision, block_reason, and response_code in P06. It matches the original npm attempt on 13c0…2f15. The separate direct HTTP request had its own ID.",
   "In Part I, the scan returned a policy result that CI could enforce. Here, Firewall itself refused the requested artifact."
  ],
  "qa": [
   {
    "q": "Why does the metadata request succeed when the package is blocked?",
    "a": "In this test the enforcement decision applied to the artifact download. Metadata can return HTTP 200 even when Firewall denies the tarball."
   }
  ],
  "sources": [
   "socket-deliverables/part-ii-firewall-results.md",
   "socket-deliverables/part-ii-firewall-workplan.md"
  ],
  "image": "socket-deliverables/images/part-ii/P06-matching-decision-log.png",
  "imageAlt": "Firewall decision event with masked request ID 13c0…2f15, the tarball path, Known malware, and HTTP 403.",
  "section": 2,
  "links": [
   {
    "title": "Socket dashboard · Settings → Security Policy",
    "url": "https://socket.dev/dashboard"
   },
   {
    "title": "Firewall decision fields",
    "url": "https://docs.socket.dev/docs/sfw-data"
   }
  ]
 },
 {
  "title": "The complete experiment",
  "short": "Full Experiment",
  "kicker": "Part II · Socket Firewall",
  "lead": "",
  "points": [],
  "workflow": [
   {
    "label": "Docker / Colima",
    "text": "Start Socket Firewall in registry mode"
   },
   {
    "label": "Terminal · curl",
    "text": "Verify TLS and the HTTP 200 health response"
   },
   {
    "label": "Container logs",
    "text": "Confirm the intended Socket organization"
   },
   {
    "label": "npm configuration",
    "text": "Route isolated test projects through Firewall"
   },
   {
    "label": "npm · Allowed install",
    "text": "Install lodash. Firewall allows the download under Monitor"
   },
   {
    "label": "npm · Blocked install",
    "text": "Attempt lodahs. Firewall denies the tarball with HTTP 403"
   },
   {
    "label": "Terminal · curl",
    "text": "Verify metadata HTTP 200 and tarball HTTP 403"
   },
   {
    "label": "Container logs",
    "text": "Correlate npm’s error with the Firewall decision"
   }
  ],
  "notes": [
   "Target 1:00 for the walkthrough. Reserve 1:00 for questions and the transition to Teach It Back.",
   "Walk through the checkpoints in order. Startup, organization connectivity, package-manager routing, and enforcement each need their own evidence.",
   "In Part I, the dependency stayed constant while the policy action changed. In Part II, the organization policy stayed constant while the packages changed.",
   "The prepared Firewall demo was retained for the panel. If Colima is stopped, start it, then bring up the prepared service and recheck health.",
   "This local deployment used fail_open: true and isolated npm projects with cold caches. The test scope excluded outage behavior, warm caches, production performance, and enterprise rollout architecture."
  ],
  "qa": [
   {
    "q": "How much does this establish about a rollout?",
    "a": "It demonstrates install-time enforcement on uncached requests through a working local registry. Outage handling, warm caches, performance, and rollout design need separate validation."
   }
  ],
  "sources": [
   "socket-deliverables/part-ii-firewall-results.md",
   "socket-deliverables/images/part-ii/P01-startup-health.png",
   "socket-deliverables/images/part-ii/P06-matching-decision-log.png",
   "socket-deliverables/part-ii-firewall-workplan.md",
   "socket-deliverables/friction-log.md",
   "socket-deliverables/appendix/socket-firewall-registry-mode-rewrite.md",
   "socket-deliverables/appendix/video-scripts/firewall-demo-v1.md",
   "socket-deliverables/appendix/videos/socket-demo-screen-only-review.mp4"
  ],
  "section": 2,
  "links": [
   {
    "title": "Socket dashboard",
    "url": "https://socket.dev/dashboard"
   },
   {
    "title": "Firewall registry setup guide",
    "url": "https://docs.socket.dev/docs/sfw-block-installs"
   },
   {
    "title": "Firewall decision fields",
    "url": "https://docs.socket.dev/docs/sfw-data"
   },
   {
    "title": "Enterprise registry configuration",
    "url": "https://docs.socket.dev/docs/socket-firewall-enterprise-registry-mode-configuration-reference"
   }
  ]
 },
 {
  "title": "The Customer Scenario",
  "short": "Customer Scenario",
  "kicker": "",
  "lead": "",
  "points": [],
  "section": 3,
  "panels": [
   {
    "label": "Widgets Manufacturing",
    "items": [
     "Courtney · Senior Manager of Engineering",
     "Widgets is in the later stages of evaluating Socket and wants to understand what adoption would change for developers."
    ]
   },
   {
    "label": "Demonstration application",
    "items": [
     "ActivityPulse",
     "Node.js CLI and Python reporting",
     "picocolors@1.1.1 adds colored terminal output"
    ]
   },
   {
    "label": "Customer questions",
    "items": [
     "Where will developers receive security feedback?",
     "When will developers need to take action?",
     "Which integration best fits our development workflow?"
    ]
   }
  ],
  "notes": [
   "Establish the customer problem first. Ask someone on the panel to play Courtney, and allow time for a reply before opening GitHub.",
   "Ask where engineers review dependency changes and who owns a failed check today. Find out whether their pipeline must enforce a control.",
   "Use the same package and version in both views. For each view, ask what the developer sees, what the result means, and who takes the next action."
  ],
  "qa": [
   {
    "q": "Why use the same change twice?",
    "a": "Holding the package and version steady makes differences in the developer workflow easier to see."
   },
   {
    "q": "What if Courtney has no strong preference?",
    "a": "Ask where the last dependency update was approved and who investigated the last failed check. Use their answer to select a pilot."
   }
  ],
  "sources": [
   "socket-deliverables/part-iii-lab.md",
   "socket-deliverables/part-iii-talk-track.pdf",
   "socket-deliverables/part-iii-talk-track.md"
  ],
  "links": []
 },
 {
  "title": "Courtney’s Call",
  "short": "Courtney’s Call",
  "kicker": "",
  "lead": "",
  "points": [],
  "section": 3,
  "video": "media/courtney-call.mp4",
  "notes": [
   "Play to the audience with meeting audio shared. The clip already includes captions.",
   "If the video is unavailable, use Courtney’s dialogue: “If we’re running Socket in GitHub Actions, where would I see the result? And if we used the GitHub App, what would I see on the PR itself?”",
   "Where do your engineers currently review dependency changes?",
   "Does your existing CI pipeline need to own the security check?",
   "Ask who would act on an exception and what should happen on a routine dependency update. Use their answers when you return to the pilot decision."
  ],
  "qa": [],
  "sources": [
   "socket-deliverables/part-iii-talk-track.md"
  ],
  "links": []
 },
 {
  "title": "The Developer Experience — GitHub Actions",
  "short": "GitHub Actions",
  "kicker": "",
  "lead": "Socket runs as part of the team’s existing CI workflow.",
  "points": [],
  "section": 3,
  "flow": [
   "Pull request",
   "GitHub Actions",
   "Socket scan and job result"
  ],
  "panels": [
   {
    "label": "Developer experience",
    "items": [
     "Pull request checks",
     "Actions job for detailed results",
     "Workflow logs to investigate a failure"
    ]
   },
   {
    "label": "Observed result",
    "items": [
     "picocolors@1.1.1",
     "Successful job",
     "“No issues found” in the verified exercise run"
    ]
   }
  ],
  "notes": [
   "Open the PR checks, select the Socket job, and expand Run Socket Security Scan. Let the learner identify the package, result, and next action.",
   "The November 23 private CI training job passed. The bundled screenshot and the public job document the original comparison. Use the saved result if access to the private run is unavailable.",
   "For optional troubleshooting, lines 32–33 of the public job show APIAccessDenied on native diff-scan comparison and requested=diff-scan effective=streaming. The streaming comparison ran to completion and the job passed. The exact missing authorization was unresolved.",
   "For a routine change, continue normal review after checking the result and any other repository requirements."
  ],
  "qa": [
   {
    "q": "Where would a developer investigate a failed check?",
    "a": "Follow the check from the PR to the Actions job. Find the first meaningful error and establish whether dependency analysis completed."
   },
   {
    "q": "Why did the preferred comparison fail in a passing job?",
    "a": "The native diff-scan operation was denied. Socket switched to streaming comparison and completed the job successfully. The log alone does not identify a missing scope."
   }
  ],
  "sources": [
   "socket-deliverables/images/part-iii/actions-compare-success.png",
   "socket-deliverables/part-iii-lab.md",
   "socket-deliverables/integration-comparison.md"
  ],
  "links": [
   {
    "title": "Original picocolors pull request",
    "url": "https://github.com/mlddragon/socket-technical-enablement-exercise/pull/1"
   },
   {
    "title": "Verified CI job · November 23 training",
    "url": "https://github.com/mlddragon/WidgetsT1/actions/runs/45234646908/job/137903003538"
   },
   {
    "title": "Verified public workflow result",
    "url": "https://github.com/mlddragon/socket-technical-enablement-exercise/actions/runs/44557864628/job/135696762163"
   }
  ]
 },
 {
  "title": "The Developer Experience — Socket GitHub App",
  "short": "Socket GitHub App",
  "kicker": "",
  "lead": "Socket provides dependency feedback directly within the GitHub pull request.",
  "points": [],
  "section": 3,
  "flow": [
   "Pull request",
   "Socket GitHub App",
   "Pull request comments and checks"
  ],
  "panels": [
   {
    "label": "Developer experience",
    "items": [
     "Dependency overview in the pull request",
     "Socket pull request checks",
     "Finding details for changes that require attention"
    ]
   },
   {
    "label": "Observed result",
    "items": [
     "picocolors@1.1.1",
     "Successful App checks",
     "Dependency feedback posted by Socket"
    ]
   }
  ],
  "notes": [
   "Open the App’s dependency overview. Identify the added package and version and show the check. Ask where the developer would go for finding details.",
   "Use the November 23 training App PR when you have access. The original public comparison PR and App comment are the fallback. Discuss duplicate feedback on Integration Decision.",
   "For an actionable result, inspect the finding and effective policy with the dependency or security owner. A routine update proceeds through the normal review.",
   "The GitHub App needs access to the selected repository. The Actions credential is specific to the separate CI path in this lab."
  ],
  "qa": [
   {
    "q": "How do I know this is the App’s result?",
    "a": "The dependency overview was posted by socket-security[bot]. Open the linked Socket check and compare it with the job-backed check on the CI path."
   },
   {
    "q": "Does this path need the Actions secret?",
    "a": "In this exercise the App uses GitHub App installation access. The separate Actions workflow uses a Socket API credential."
   }
  ],
  "sources": [
   "socket-deliverables/part-iii-talk-track.md",
   "socket-deliverables/integration-comparison.md",
   "socket-deliverables/part-iii-lab.md"
  ],
  "links": [
   {
    "title": "App dependency feedback · November 23 training",
    "url": "https://github.com/mlddragon/WidgetsT2/pull/1#issuecomment-7109646009"
   },
   {
    "title": "Original Socket App comment",
    "url": "https://github.com/mlddragon/socket-technical-enablement-exercise/pull/1#issuecomment-7012611620"
   },
   {
    "title": "Public comparison PR",
    "url": "https://github.com/mlddragon/socket-technical-enablement-exercise/pull/1"
   }
  ]
 },
 {
  "title": "Troubleshooting and Policy Enforcement",
  "short": "Troubleshooting & Enforcement",
  "kicker": "",
  "lead": "A failed check does not necessarily indicate a security finding.",
  "points": [],
  "section": 3,
  "comparison": [
   {
    "label": "Integration failure",
    "example": "HTTP 401 · Authentication failure",
    "tone": "integration",
    "details": [
     "What happened · Dependency analysis did not complete.",
     "Next action · Investigate the integration credential.",
     "Typical owner · CI administrator or integration owner."
    ]
   },
   {
    "label": "Policy violation",
    "example": "Separate PyYAML CLI example · Completed scan with Block",
    "tone": "policy",
    "details": [
     "What happened · A finding triggered a blocking policy action.",
     "Next action · Review remediation or the appropriate exception process.",
     "Typical owner · Engineering or Security."
    ]
   }
  ],
  "verification": {
   "label": "Merge enforcement",
   "correlation": "A failed check prevents merging only when the repository’s applicable rules require that check to pass."
  },
  "notes": [
   "Show the saved historical Actions 401. The Python CLI exited 3 before completing dependency analysis. Ask what that run established about the package. Keep credential values off screen.",
   "Show PyYAML Block and Warn only as separate Part I CLI evidence. Block was policy: error, healthy: false, original exit 1. Warn was policy: warn, healthy: true, original exit 0. A report can be generated successfully for an unhealthy scan.",
   "Use a repository’s applicable branch protection or ruleset before saying a check will stop a merge. A policy result, check conclusion, and merge requirement answer different questions.",
   "Optional challenge: What happens when a workflow contains an error message but ultimately completes successfully? The native diff comparison was denied in the passing job, the streaming fallback completed, and the final job succeeded. Lines 32–33 show the fallback."
  ],
  "qa": [
   {
    "q": "Does a 401 say anything about whether a dependency is malicious?",
    "a": "It identifies an authentication failure before dependency analysis completed. The run produced no dependency verdict."
   },
   {
    "q": "Can an engineer still merge?",
    "a": "Inspect the applicable repository rules and which checks they require. The details of the failed check do not establish a merge requirement."
   },
   {
    "q": "What if a log reports an error but the job passes?",
    "a": "Find the denied operation and what ran afterward. The saved job switched to streaming comparison and ultimately completed successfully."
   }
  ],
  "sources": [
   "socket-deliverables/images/part-iii/actions-compare-failed.png",
   "socket-deliverables/images/part-iii/actions-search-401.png",
   "socket-deliverables/images/part-iii/cli-policy-block.png",
   "socket-deliverables/images/part-iii/cli-policy-warn.png",
   "socket-deliverables/images/part-iii/actions-compare-success.png",
   "socket-deliverables/part-iii-lab.md",
   "socket-deliverables/part-iii-talk-track.md"
  ],
  "links": [
   {
    "title": "Socket dashboard · Settings → Security Policy",
    "url": "https://socket.dev/dashboard"
   }
  ]
 },
 {
  "title": "Choosing the Right Integration",
  "short": "Integration Decision",
  "kicker": "",
  "lead": "The customer’s development workflow should drive the integration decision.",
  "points": [],
  "section": 3,
  "matrix": {
   "columns": [
    "Consideration",
    "Socket GitHub App",
    "GitHub Actions"
   ],
   "rows": [
    [
     "Primary experience",
     "Pull request",
     "CI workflow"
    ],
    [
     "Configuration",
     "App installation and repository access",
     "Workflow and API credential"
    ],
    [
     "Investigation",
     "PR feedback and finding details",
     "Job results and workflow logs"
    ],
    [
     "Best fit",
     "Existing GitHub review process",
     "Pipeline-owned security controls"
    ]
   ],
   "scope": "Both integrations can surface feedback in a pull request. The matrix shows where each primarily fits."
  },
  "panels": [
   {
    "label": "Considerations when using both",
    "text": "Our comparison produced two dependency comments for the same change. Choose one primary feedback path unless the customer has a specific reason to use both."
   },
   {
    "label": "Recommended pilot",
    "text": "One repository · Actionable feedback · Defined exception ownership"
   }
  ],
  "notes": [
   "Return to Courtney’s original question and the answers about where engineers review changes and who owns the check.",
   "Ask which integration the learner would pilot and what requirement would change their mind. Have them explain and defend their choice using one of Courtney’s answers.",
   "Open the original PR’s comments if needed. socket-security[bot] and github-actions[bot] both posted dependency feedback. The exercise retained the App for routine review and moved Actions to manual dispatch for testing. A customer can still justify a pipeline-owned control.",
   "Agree with the customer on the pilot repository, an actionable feedback path, who owns exceptions, and how to tell whether routine updates gained extra steps.",
   "The AI-use log, teaching package, and verification PR #2 remain in Evidence & demos if asked about drafting, the patch correction, or the November 23 training runs. Independent learner timing remains unmeasured.",
   "Transition: “You’ve seen how I teach the decision. Now let’s look at how a new SE practices it and how I check that they can do it independently.”"
  ],
  "qa": [
   {
    "q": "What would make you change the pilot recommendation?",
    "a": "A requirement for a specific workflow step or pipeline-owned control would lead me to investigate Actions and verify the merge settings with the CI owner."
   },
   {
    "q": "How would you adapt this for a TAM or Support engineer?",
    "a": "For a TAM, focus on adoption and exception ownership. For Support, practice gathering the run link, failed stage, and next owner. The primary learner remains a new SE."
   }
  ],
  "sources": [
   "socket-deliverables/integration-comparison.md",
   "socket-deliverables/part-iii-talk-track.pdf",
   "socket-deliverables/part-iii-talk-track.md",
   "socket-deliverables/ai-use-and-verification.md",
   "socket-deliverables/teaching-package.md",
   "socket-deliverables/part-iii-readiness-check.md"
  ],
  "links": [
   {
    "title": "Original comparison PR · both comments",
    "url": "https://github.com/mlddragon/socket-technical-enablement-exercise/pull/1"
   },
   {
    "title": "Original comment · socket-security[bot]",
    "url": "https://github.com/mlddragon/socket-technical-enablement-exercise/pull/1#issuecomment-7012611620"
   },
   {
    "title": "Original comment · github-actions[bot]",
    "url": "https://github.com/mlddragon/socket-technical-enablement-exercise/pull/1#issuecomment-7014418426"
   },
   {
    "title": "Verification PR #2",
    "url": "https://github.com/mlddragon/socket-technical-enablement-exercise/pull/2"
   }
  ]
 },
 {
  "title": "Hands-on Lab",
  "short": "Hands-on Lab",
  "kicker": "Lab & Readiness · Deliverable 1",
  "lead": "Develop the ability to demonstrate both Socket integrations and recommend an appropriate customer pilot.",
  "points": [],
  "section": 4,
  "panels": [
   {
    "label": "widgets-ci",
    "items": [
     "GitHub Actions",
     "Dedicated workflow and scoped credential"
    ]
   },
   {
    "label": "widgets-app",
    "items": [
     "Socket GitHub App",
     "Dedicated App integration"
    ]
   }
  ],
  "context": "Shared foundation · Same ActivityPulse template and dependency change.",
  "timeline": [
   {
    "time": "0–3 min",
    "label": "Discovery and initial recommendation"
   },
   {
    "time": "3–10 min",
    "label": "Prepare and trigger both integrations"
   },
   {
    "time": "10–18 min",
    "label": "Verify the developer experience"
   },
   {
    "time": "18–25 min",
    "label": "Rehearse the customer recommendation"
   },
   {
    "time": "25–30 min",
    "label": "Practical readiness assessment"
   }
  ],
  "callout": {
   "label": "Focused learning objective",
   "text": "Pre-staged resources let learners focus on integration behavior, developer experience, and customer recommendations. Complementary training develops independent environment setup."
  },
  "notes": [
   "Allow 2:30. Position this 30-minute lab as focused technical training within a broader Socket SE curriculum. This lab isolates one competency so the learner can connect technical behavior to a customer recommendation.",
   "widgets-ci gets the Actions workflow and scoped Actions secret. widgets-app gets Socket GitHub App access. Using two independent training repositories isolates who produced each result and where engineers see it.",
   "The ActivityPulse template supplies the Node.js CLI and Python reporter. The same picocolors.patch changes both clones. socket-ci.yml adds the starter workflow only to widgets-ci.",
   "Before timing starts, the facilitator gives the learner authorized training-org and repository access, pre-stages the Actions secret in widgets-ci, and confirms App access for widgets-app. The lab lists the downloads and local clone names. Keep credentials off screen.",
   "If access or processing stalls, use the saved PR, job and screenshots. Record whether the learner used their own results or saved evidence.",
   "Complementary foundational labs develop local tooling and dependencies, Git and repository workflows, package management, CI/CD, container operation, authentication, networking, and certificate trust as relevant to SE work. Focused labs develop individual capabilities before they are brought together in the Field Readiness Assessment.",
   "Both independent paths were technically verified on November 23 in separate private training repositories. Independent completion by a new learner within 30 minutes has yet to be measured."
  ],
  "qa": [
   {
    "q": "What can the panel inspect publicly?",
    "a": "PR #2 shows both integrations on one pre-authorized exercise repository. The November 23 walkthrough separately verified the two independent private training paths."
   },
   {
    "q": "Why stage access and a starter workflow?",
    "a": "The target behavior is demonstrating and recommending the integration. Learners develop secure setup, repository preparation, and troubleshooting independently in complementary activities."
   },
   {
    "q": "Has a new learner completed the whole lab in 30 minutes?",
    "a": "The two private technical paths ran on November 23. A timed, independent learner trial remains pending."
   }
  ],
  "sources": [
   "socket-deliverables/part-iii-lab.md",
   "socket-deliverables/teaching-package.md",
   "socket-deliverables/images/part-iii/actions-compare-success.png",
   "README.md"
  ],
  "links": [
   {
    "title": "ActivityPulse training template",
    "url": "https://github.com/mlddragon/activitypulse-demo-template"
   },
   {
    "title": "Download picocolors.patch",
    "url": "https://github.com/mlddragon/socket-technical-enablement-exercise/blob/main/socket-deliverables/lab-assets/picocolors.patch"
   },
   {
    "title": "Download socket-ci.yml",
    "url": "https://github.com/mlddragon/socket-technical-enablement-exercise/blob/main/socket-deliverables/lab-assets/socket-ci.yml"
   },
   {
    "title": "Verification PR #2",
    "url": "https://github.com/mlddragon/socket-technical-enablement-exercise/pull/2"
   }
  ]
 },
 {
  "title": "Customer Talk Track",
  "short": "Customer Talk Track",
  "kicker": "Lab & Readiness · Deliverable 2",
  "lead": "A one-page field reference for demonstrating Socket to engineering leadership.",
  "points": [],
  "section": 4,
  "panels": [
   {
    "label": "Discovery",
    "text": "Understand the customer’s existing development workflow."
   },
   {
    "label": "Demonstration",
    "text": "Show the same dependency change through both integrations."
   },
   {
    "label": "Objection handling",
    "text": "Duplicate feedback, failed checks, and merge enforcement."
   },
   {
    "label": "Recommendation",
    "text": "Agree on an appropriate pilot and its success criteria."
   }
  ],
  "image": "socket-deliverables/part-iii-talk-track.pdf",
  "imageAlt": "The submitted one-page Widgets Mfg talk track, with discovery, both integration paths, customer objections, and the pilot recommendation.",
  "notes": [
   "Allow 1:10. Enlarge the submitted talk track when the panel wants to read it.",
   "The talk track is a reusable field job aid for real engineering leadership conversations. It offers a structure the SE can adapt to the customer’s answers.",
   "Learners can refer to it during the practical readiness assessment. The evaluator observes how they use it to complete the task and handle a question independently.",
   "The standard is performing the demo, handling the objection, and recommending a defensible next step. Effective use of reference material is part of that performance."
  ],
  "qa": [
   {
    "q": "What makes this more useful than memorizing a script?",
    "a": "The job aid gives the learner the sequence, likely objections, and evidence while leaving room to respond to the customer’s actual workflow."
   }
  ],
  "sources": [
   "socket-deliverables/part-iii-talk-track.pdf",
   "socket-deliverables/part-iii-talk-track.md",
   "socket-deliverables/part-iii-readiness-check.md"
  ],
  "links": []
 },
 {
  "title": "Practical Readiness Assessment",
  "short": "Practical Readiness Assessment",
  "kicker": "Lab & Readiness · Deliverable 3",
  "lead": "Can the SE independently demonstrate Socket and recommend an appropriate integration?",
  "points": [],
  "section": 4,
  "timeline": [
   {
    "time": "3 min",
    "label": "Technical demonstration",
    "text": "Show both integrations. Identify the producer, package and version, result, and developer’s next action."
   },
   {
    "time": "1 min",
    "label": "Customer objection",
    "text": "Answer an unannounced question about troubleshooting or enforcement."
   },
   {
    "time": "1 min",
    "label": "Technical recommendation",
    "text": "Recommend a customer-specific pilot and name a constraint that would change it."
   }
  ],
  "panels": [
   {
    "label": "Ready to demo",
    "text": "Independent, evidence-based performance across all three tasks with zero critical errors."
   },
   {
    "label": "Coaching and reassessment",
    "text": "Directional assistance, unsupported decisions, or critical errors require more practice and reassessment."
   }
  ],
  "context": "Measured outcome · Readiness to give this specific customer demo.",
  "notes": [
   "Allow 2:30. Record the learner’s initial recommendation before instruction and final recommendation afterward. Use them as separate coaching observations.",
   "Allow one neutral prompt, such as “Where would you check?”, and record it. Directional help means further practice. A critical error overrides otherwise successful performance.",
   "Critical errors include exposing credentials, treating authentication failure as a dependency verdict, promising merge enforcement without checking, or recommending an unauthorized broad bypass.",
   "Reassess with a different but equivalent customer objection or constraint. The customer talk track and appropriate references are allowed.",
   "Saved evidence can establish readiness to present this demonstration. Mark live setup verified only when the learner’s two integration paths ran and produced the expected results.",
   "This five-minute check measures independent delivery of one customer demonstration. Complementary training and the integrated assessment observe independent setup and broader field performance."
  ],
  "qa": [
   {
    "q": "Can a learner pass using saved results?",
    "a": "Saved results can support presentation readiness for this demo. Live setup is verified only when the learner’s own training paths actually run and return the expected results."
   },
   {
    "q": "What changes for TAMs or Support engineers?",
    "a": "Keep evidence-based performance and adapt the task. For a TAM, emphasize adoption and ownership. For Support, emphasize isolation, evidence collection, and the next owner."
   }
  ],
  "sources": [
   "socket-deliverables/part-iii-readiness-check.md",
   "socket-deliverables/part-iii-talk-track.pdf",
   "socket-deliverables/part-iii-lab.md"
  ],
  "links": []
 },
 {
  "title": "Field Readiness Assessment",
  "short": "Field Readiness Assessment",
  "kicker": "Lab & Readiness · Proposed program extension",
  "lead": "Assess readiness to advance a supervised customer proof of concept.",
  "points": [],
  "section": 4,
  "context": "50–60-minute scenario combining foundational technical training, focused Socket practice, and integrated field performance.",
  "matrix": {
   "label": "Field readiness competencies",
   "columns": [
    "Competency",
    "Observed performance"
   ],
   "rows": [
    [
     "Customer discovery",
     "Identify requirements and measurable success criteria."
    ],
    [
     "Technical demonstration",
     "Independently prepare a working environment on the SE’s own device, configure Socket, run the live demo, and verify the result."
    ],
    [
     "Security policy judgment",
     "Interpret findings and recommend an appropriate policy."
    ],
    [
     "Enterprise troubleshooting",
     "Isolate failures, gather evidence, and name the next action and owner."
    ],
    [
     "Customer handoff",
     "Communicate verified results and advance the POC."
    ]
   ]
  },
  "callout": {
   "label": "Pass criteria",
   "text": "At least 16/20 overall · At least 3/4 per competency · Zero critical failures"
  },
  "validation": [
   "Learner pilot",
   "Evaluator calibration",
   "Observed customer POC",
   "30-day follow-up"
  ],
  "notes": [
   "Allow 2:30, followed by 1:00 for questions and transition. Foundational technical training develops the broader ecosystem skills. Focused labs teach individual product and workflow competencies. Integrated readiness observes those competencies together.",
   "Independent preparation on the learner’s own device is central. Observe verification and configuration of tooling or dependencies, the repo and chosen integration, and secure authentication. Include connectivity and certificate trust when the assigned scenario requires them.",
   "Supply scenario information, approved reference and installation resources, authorized access or credentials, and externally provisioned services beforehand. The candidate configures their own environment and Socket route, triggers the live change, verifies the actual result, and troubleshoots as needed.",
   "Record device and setup evidence, the resulting live run or scan, and the verified outcome. A saved or preconfigured demonstration cannot earn 3 in Technical Demonstration. The evaluator can record it as rehearsal and schedule an independently observed replay.",
   "Score each competency 0–4. 0 is absent or unsafe. 1 is unable after a neutral prompt. 2 is partial or relies on directional help. 3 is independent with evidence, limits, and owner. 4 adds adaptation to a changed condition. Record neutral prompts and cap directional help at 2.",
   "Critical failures override the score. Examples include secret disclosure, unauthorized broad policy weakening, treating authentication failure as proof of malware, mistaking simulated or unrun results for verified results, or concealing an unresolved dependency.",
   "Use the simulated Kubernetes CI runner behind an outbound proxy and internal CA, with an enterprise registry and a proposed Firewall route. Ask the learner to isolate one failed hop and distinguish an appropriate specialist escalation from an avoidable request answerable with shared guidance.",
   "Use equivalent baseline and post-training cases with the same scoring and help rules. Calibrate evaluators, ask a manager to observe the first POC, then follow up at 30 days.",
   "Learner trials, timing, evaluator calibration, and field validation remain pending. Independent setup may strain the existing 15-minute technical slot, even with installations and access provisioned beforehand. Measure it in trials."
  ],
  "qa": [
   {
    "q": "What can be prepared before the assessment?",
    "a": "Authorized service access, credentials, downloads, documentation, and scenario information may be ready. The learner configures their own device, repo, credentials, and Socket integration as necessary to produce the live result."
   },
   {
    "q": "Can the candidate pass with saved results?",
    "a": "The pass requires independently observed setup and successful live execution, with an identified run or scan and verified outcome. Saved results can be used for rehearsal and discussion."
   },
   {
    "q": "How would you validate transfer to the field?",
    "a": "Compare equivalent baseline and post-training cases, calibrate raters, then compare manager-observed independence, milestone progress, and appropriate versus avoidable escalation."
   }
  ],
  "sources": [
   "socket-deliverables/appendix/field-readiness-assessment.md",
   "socket-deliverables/appendix/README.md",
   "socket-deliverables/part-iii-readiness-check.md"
  ],
  "links": []
 },
 {
  "title": "Live Technical Demonstration",
  "short": "Live Demonstration",
  "kicker": "",
  "lead": "",
  "points": [],
  "notes": [
   "Ask what the panel would like to change or see. Establish the expected observable behavior before editing. Adapt where feasible.",
   "If the panel leaves the choice open, use the prepared dynamic activity-type count enhancement. Open live-demo and run Run.command. Keep the baseline Terminal window available.",
   "Run.command uses Node and the prepared Python environment with PyYAML 6.0.2. Python reads the CSV or YAML and returns by_activity_type. The Node CLI formats the resulting summary.",
   "If asked to demonstrate Firewall, use the authorized prepared environment and the Part II evidence and commands. Check Colima, container status, and HTTP 200 health first.",
   "Use the saved Part II evidence if the service is unavailable. Identify the capture as historical evidence."
  ],
  "qa": [
   {
    "q": "Why make a format change in the Node CLI?",
    "a": "The reporter already supplies by_activity_type. The CLI can count those keys while formatting the existing summary."
   }
  ],
  "sources": [
   "activitypulse/cli.js",
   "activitypulse/report.py",
   "socket-deliverables/part-ii-firewall-results.md",
   "socket-deliverables/images/part-ii/P01-startup-health.png",
   "socket-deliverables/images/part-ii/P06-matching-decision-log.png"
  ],
  "section": 5,
  "links": [
   {
    "title": "Local rehearsal files",
    "url": "live-demo/"
   }
  ],
  "flow": [
   "CSV / YAML data",
   "Python reporting",
   "Node.js CLI"
  ],
  "flowLabel": "ActivityPulse data flow",
  "panels": [
   {
    "label": "Verified bundled baseline",
    "items": [
     "117 activity records",
     "Five distinct activity types"
    ]
   }
  ],
  "stepLabel": "Demonstration approach",
  "steps": [
   "Establish the requirement",
   "Inspect the implementation",
   "Make the change",
   "Verify the result"
  ]
 },
 {
  "title": "Implementation and Verification",
  "short": "Implementation & Verification",
  "kicker": "",
  "lead": "",
  "points": [],
  "notes": [
   "Rehearsal step 1. Run live-demo/Run.command and retain the baseline output.",
   "Step 2. Open live-demo/activitypulse/cli.js.",
   "Step 3. Directly below the line printing total records, add: console.log(`Activity types: ${Object.keys(summary.by_activity_type).length}`);",
   "Step 4. Save and rerun the application.",
   "Step 5. Verify Activity types: 5 directly below Total records: 117.",
   "Step 6. Confirm application: 27, follow_up: 16, interview: 4, job_readiness: 4, and other: 66.",
   "Step 7. From live-demo, run diff -u baseline.js activitypulse/cli.js.",
   "Step 8. Expect only the intended added line. A diff exit status of 1 means the files differ.",
   "Step 9. Remove the added line to reset the rehearsal and verify the diff is empty.",
   "Use the existing summary in Node. A sixth distinct type raises the type count. Another record in an existing type increases that category and the overall total while leaving the type count unchanged. A headers-only CSV yields an empty mapping and zero types.",
   "The example adds no dependency. Use the original pull request and earlier dependency experiments to discuss Socket’s dependency-review behavior."
  ],
  "qa": [
   {
    "q": "Why make this change in Node?",
    "a": "The Python summary already contains the grouped counts. Node formats the output using those keys, with no second pass through the input."
   },
   {
    "q": "What changes with another activity record?",
    "a": "A new type raises the distinct type count. An existing type raises its category count. Both raise total records."
   },
   {
    "q": "What does a headers-only CSV produce?",
    "a": "The reporter yields zero total records and an empty by_activity_type mapping, which gives zero types."
   },
   {
    "q": "Does the edit demonstrate a new Socket finding?",
    "a": "The edit changes output formatting and leaves dependencies unchanged. PR #1 and the earlier experiments supply the dependency-review evidence."
   }
  ],
  "sources": [
   "activitypulse/cli.js",
   "activitypulse/report.py",
   "activitypulse/data/README.md",
   "socket-deliverables/integration-comparison.md"
  ],
  "section": 5,
  "links": [
   {
    "title": "Local rehearsal files",
    "url": "live-demo/"
   },
   {
    "title": "Original dependency comparison PR",
    "url": "https://github.com/mlddragon/socket-technical-enablement-exercise/pull/1"
   }
  ],
  "panels": [
   {
    "label": "Implementation",
    "text": "Make the smallest appropriate change using the application’s existing architecture."
   },
   {
    "label": "Verification",
    "text": "Confirm the requested behavior and check that existing functionality remains intact."
   }
  ],
  "stepLabel": "Example acceptance criteria · Dynamic activity-type count",
  "criteria": [
   "Total activity records remain 117.",
   "The distinct activity-type count is calculated dynamically.",
   "Existing category counts remain unchanged.",
   "The diff contains only the intended change."
  ]
 },
 {
  "title": "Optional extras",
  "short": "Optional extras",
  "kicker": "",
  "lead": "",
  "points": [],
  "notes": [],
  "qa": [],
  "sources": [],
  "section": null,
  "extras": [
   {
    "group": "Technical Resources",
    "label": "Command reference",
    "text": "Private presenter reference with copy-ready commands by section",
    "commands": true
   },
   {
    "group": "Technical Resources",
    "label": "CLI Permissions Explorer",
    "text": "Filter commands and see which scopes to select",
    "ref": "socket-deliverables/appendix/permissions-explorer"
   },
   {
    "group": "Technical Resources",
    "label": "Screen-only Socket demo",
    "text": "GitHub Actions and Socket Firewall · 7:45",
    "ref": "socket-deliverables/appendix/videos/socket-demo-screen-only-review.mp4"
   },
   {
    "group": "Documentation Improvements",
    "label": "Package Scores rewrite",
    "text": "A guide for choosing what to investigate first",
    "ref": "socket-deliverables/appendix/package-scores-rewrite.md"
   },
   {
    "group": "Documentation Improvements",
    "label": "Firewall Registry Mode rewrite",
    "text": "Setup and deployment guidance organized around reader tasks",
    "ref": "socket-deliverables/appendix/socket-firewall-registry-mode-rewrite.md"
   },
   {
    "group": "Documentation Improvements",
    "label": "Progressive disclosure skill",
    "text": "Reusable instructions behind the documentation rewrites",
    "ref": "socket-deliverables/appendix/progressive-disclosure-docs/SKILL.md"
   },
   {
    "group": "Enablement and Readiness",
    "label": "Proposed field-readiness assessment",
    "text": "Supervised customer pilot exercise and scoring guide",
    "ref": "socket-deliverables/appendix/field-readiness-assessment.md"
   },
   {
    "group": "Enablement and Readiness",
    "label": "Teaching package and required deliverables",
    "text": "Lab, customer talk track, and practical readiness check",
    "ref": "socket-deliverables/teaching-package.md"
   },
   {
    "group": "Enablement and Readiness",
    "label": "Firewall demo script",
    "text": "Draft for a short registry-mode walkthrough",
    "ref": "socket-deliverables/appendix/video-scripts/firewall-demo-v1.md"
   },
   {
    "group": "Enablement and Readiness",
    "label": "CLI and GitHub App demo script",
    "text": "Draft walkthrough of the CLI and pull request feedback",
    "ref": "socket-deliverables/appendix/video-scripts/cli-github-demo-v1.md"
   },
   {
    "group": "Research and Verification",
    "label": "AI use and verification log",
    "text": "AI errors, human corrections, technical checks, and validation limits",
    "ref": "socket-deliverables/ai-use-and-verification.md"
   },
   {
    "group": "Research and Verification",
    "label": "Research index",
    "text": "Field notes, teaching research, and ActivityPulse planning",
    "ref": "research/README.md"
   },
   {
    "group": "Research and Verification",
    "label": "Full repository appendix",
    "text": "Complete index of supporting materials",
    "url": "https://github.com/mlddragon/socket-technical-enablement-exercise/blob/main/socket-deliverables/appendix/README.md"
   }
  ]
 }
];
