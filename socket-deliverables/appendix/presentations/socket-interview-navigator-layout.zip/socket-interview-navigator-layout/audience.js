'use strict';
const token=location.hash.slice(1);
let current=-1,ref=null,mirroring=false;
const reconnectChannel=token && typeof BroadcastChannel==='function'?new BroadcastChannel('socket-audience-'+token):null;
function sendToPresenter(data){
 if(window.opener&&!window.opener.closed)window.opener.postMessage(data,'*');
 else reconnectChannel?.postMessage(data);
}
function reportPosition(){
 if(mirroring)return;
 const reader=byId('stage').querySelector('.reader');
 if(!reader)return;
 const expanded=[...reader.querySelectorAll('details')].flatMap((el,i)=>el.open?[i]:[]);
 const scroll=reader.scrollTop/Math.max(1,reader.scrollHeight-reader.clientHeight);
 sendToPresenter({kind:'socket-reader-position',token,ref,scroll,expanded});
}
function videoStatus(label){
 sendToPresenter({kind:'socket-video-status',token,index:current,label});
}
function sendPosition(kind,returnedFromLive=false){
 sendToPresenter({kind,token,protocol:audienceProtocol,index:current,ref,returnedFromLive});
}
function hello(){
 const returnedFromLive=Boolean(history.state?.socketLive);
 if(returnedFromLive)history.replaceState(null,'');
 sendPosition('socket-ready',returnedFromLive);
}
function receive(e,viaChannel=false){
 if((!viaChannel&&e.source!==window.opener) || !e.data||!token||e.data.token!==token)return;
 if(!viaChannel && location.protocol!=='file:'&&e.origin!==location.origin)return;
 if(e.data.kind==='socket-focus'){window.focus();return;}
 if(e.data.kind==='socket-live'){
   if(Object.values(catalog).some(item=>item.kind==='live'&&item.url===e.data.url)){
     history.replaceState({socketLive:true},'');
     location.assign(e.data.url);
   }
   return;
 }
 if(e.data.kind==='socket-video'){
   const video=byId('callVideo');
   if(!video || ref || current!==e.data.index)return;
   if(e.data.action==='pause')video.pause();
   if(e.data.action==='play')video.play().catch(()=>{
     const note=byId('clipNotice');
     if(!note || !video.isConnected)return;
     note.hidden=false;note.textContent='Select Play in this window to start the clip.';
     videoStatus(note.textContent);
   });
   return;
 }
 if(e.data.kind==='socket-page'){
   if(e.data.ref===ref && [1,-1].includes(e.data.direction)){
     const reader=byId('stage').querySelector('.reader');
     if(reader)reader.scrollBy(0,e.data.direction*reader.clientHeight*.82);
   }
   return;
 }
 if(e.data.kind!=='socket-slide')return;
 const {index,ref:next}=e.data;
 if(!Number.isInteger(index)||!deck[index]||(next&&!catalog[next]))return;
 mirroring=Boolean(e.data.mirrorEvidence);
 if(index!==current||ref!==next){
   byId('stage').querySelector('video')?.pause();
   current=index;ref=next;byId('stage').innerHTML=board(index,ref,false);
   const video=byId('callVideo');
   if(video){
     video.onplaying=()=>{byId('clipNotice').hidden=true;videoStatus('Playing in audience window');};
     video.onpause=()=>{if(video.isConnected)videoStatus('Paused');};
     video.onended=()=>videoStatus('Finished');
     video.onerror=()=>{const note=byId('clipNotice');note.hidden=false;note.textContent='Clip unavailable.';videoStatus('Clip unavailable. Advance to GitHub Actions.');};
   }
   const article=byId('stage').querySelector('.reader');
   if(article){article.addEventListener('scroll',reportPosition,{passive:true});article.addEventListener('toggle',reportPosition,true);}
   sendPosition('socket-rendered');
 }
 const reader=byId('stage').querySelector('.reader');
 if(reader && e.data.mirrorEvidence){
   const opened=Array.isArray(e.data.expanded)?e.data.expanded:[];
   reader.querySelectorAll('details').forEach((el,k)=>el.open=opened.includes(k));
   reader.scrollTop=Math.max(0,Math.min(1,Number(e.data.scroll)||0))*(reader.scrollHeight-reader.clientHeight);
 }
}
window.addEventListener('message',event=>receive(event));
reconnectChannel?.addEventListener('message',event=>receive(event,true));
byId('stage').innerHTML=board(0,null,false);
byId('full').onclick=async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await document.documentElement.requestFullscreen();}catch{byId('full').title='Use the browser fullscreen command';}};
hello();setInterval(hello,2000);
window.addEventListener('pageshow',hello);
document.addEventListener('visibilitychange',()=>{if(!document.hidden)hello();});
