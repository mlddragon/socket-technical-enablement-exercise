window.LIBRARY = {
  "AGENTS.md": {
    "title": "Socket exercise repository guide",
    "url": "library/AGENTS.html"
  },
  "README.md": {
    "title": "Socket Technical Enablement Exercise",
    "url": "library/README.html"
  },
  "activitypulse/data/README.md": {
    "title": "ActivityPulse anonymized sample dataset",
    "url": "library/activitypulse/data/README.html"
  },
  "project/teaching-package.md": {
    "title": "Part III · Teaching package",
    "url": "library/project/teaching-package.html"
  },
  "research/README.md": {
    "title": "Research workspace",
    "url": "library/research/README.html"
  },
  "research/assumptions-and-traceability.md": {
    "title": "Assumptions and traceability",
    "url": "library/research/assumptions-and-traceability.html"
  },
  "research/community-signals.md": {
    "title": "Public user friction signals (unverified reports)",
    "url": "library/research/community-signals.html"
  },
  "research/discord-enablement-themes-2026.md": {
    "title": "Discord enablement themes (May–November 2026)",
    "url": "library/research/discord-enablement-themes-2026.html"
  },
  "research/planning/PRD.md": {
    "title": "ActivityPulse — Product Requirements Document",
    "url": "library/research/planning/PRD.html"
  },
  "research/planning/activity-log.md": {
    "title": "Project activity log",
    "url": "library/research/planning/activity-log.html"
  },
  "research/planning/artifact-inventory.md": {
    "title": "Artifact inventory as of November 18, 2026",
    "url": "library/research/planning/artifact-inventory.html"
  },
  "research/planning/assets/policy-block-vs-warn.svg": {
    "title": "Historical Block and Warn comparison mockup",
    "url": "library/research/planning/assets/policy-block-vs-warn.svg"
  },
  "research/planning/cli-permissions-worksheet-handoff.md": {
    "title": "Socket CLI permissions worksheet — Work-thread handoff",
    "url": "library/research/planning/cli-permissions-worksheet-handoff.html"
  },
  "research/planning/part-i-conceptual-notes.md": {
    "title": "Part I §4 — Technical reference notes (living draft)",
    "url": "library/research/planning/part-i-conceptual-notes.html"
  },
  "research/planning/part-i-execution-plan.md": {
    "title": "Socket Part I — Complete Execution Plan",
    "url": "library/research/planning/part-i-execution-plan.html"
  },
  "research/planning/prerequisites-checklist.md": {
    "title": "ActivityPulse / Socket Part I — Prerequisite checklist",
    "url": "library/research/planning/prerequisites-checklist.html"
  },
  "research/sources.md": {
    "title": "Source index",
    "url": "library/research/sources.html"
  },
  "research/training-platform-options-2026-11-18.md": {
    "title": "Training format options for the Socket exercise",
    "url": "library/research/training-platform-options-2026-11-18.html"
  },
  "socket-deliverables/PROJECT-STATUS.md": {
    "title": "Socket Technical Enablement Exercise — Current Project Status",
    "url": "library/socket-deliverables/PROJECT-STATUS.html"
  },
  "socket-deliverables/README.md": {
    "title": "Socket Deliverables",
    "url": "library/socket-deliverables/README.html"
  },
  "socket-deliverables/ai-use-and-verification.md": {
    "title": "AI use and verification log",
    "url": "library/socket-deliverables/ai-use-and-verification.html"
  },
  "socket-deliverables/appendix/videos/socket-demo-screen-only-review.mp4": {
    "title": "Screen-only Socket demo (7:45)",
    "url": "media/socket-demo-screen-only-review.mp4",
    "kind": "video"
  },
  "socket-deliverables/appendix/permissions-explorer": {
    "title": "Socket CLI Permissions Explorer",
    "url": "https://docs.google.com/spreadsheets/d/1iQLzZkCqyz8XxqFjk2UQPY5TDkvVa1a49uHQ3eLOBPY/edit?usp=sharing",
    "kind": "online"
  },
  "socket-deliverables/appendix/README.md": {
    "title": "Appendix · Additional work and supporting research",
    "url": "library/socket-deliverables/appendix/README.html"
  },
  "socket-deliverables/appendix/field-readiness-assessment.md": {
    "title": "Proposed field readiness assessment · Widgets Mfg",
    "url": "library/socket-deliverables/appendix/field-readiness-assessment.html"
  },
  "socket-deliverables/appendix/package-scores-rewrite.md": {
    "title": "Package scores",
    "url": "library/socket-deliverables/appendix/package-scores-rewrite.html"
  },
  "socket-deliverables/appendix/progressive-disclosure-docs/SKILL.md": {
    "title": "Progressive disclosure for technical docs",
    "url": "library/socket-deliverables/appendix/progressive-disclosure-docs/SKILL.html"
  },
  "socket-deliverables/appendix/socket-firewall-registry-mode-rewrite.md": {
    "title": "Socket Firewall Enterprise in Registry Mode",
    "url": "library/socket-deliverables/appendix/socket-firewall-registry-mode-rewrite.html"
  },
  "socket-deliverables/appendix/video-scripts/cli-github-demo-v1.md": {
    "title": "Draft video script v1 — Socket CLI + GitHub App: Discover, Decide, Review",
    "url": "library/socket-deliverables/appendix/video-scripts/cli-github-demo-v1.html"
  },
  "socket-deliverables/appendix/video-scripts/firewall-demo-v1.md": {
    "title": "Draft video script v1 — Socket Firewall: Stop a Package at Download",
    "url": "library/socket-deliverables/appendix/video-scripts/firewall-demo-v1.html"
  },
  "socket-deliverables/friction-log.md": {
    "title": "Firsthand friction log",
    "url": "library/socket-deliverables/friction-log.html"
  },
  "socket-deliverables/images/part-ii/P01-startup-health.png": {
    "title": "P01 · Firewall startup and health",
    "url": "library/socket-deliverables/images/part-ii/P01-startup-health.png"
  },
  "socket-deliverables/images/part-ii/P06-matching-decision-log.png": {
    "title": "P06 · Matching Firewall decision log",
    "url": "library/socket-deliverables/images/part-ii/P06-matching-decision-log.png"
  },
  "socket-deliverables/images/part-iii/actions-attempt-1.png": {
    "title": "GitHub Actions · First attempt",
    "url": "library/socket-deliverables/images/part-iii/actions-attempt-1.png"
  },
  "socket-deliverables/images/part-iii/actions-compare-failed.png": {
    "title": "GitHub Actions · Failed comparison",
    "url": "library/socket-deliverables/images/part-iii/actions-compare-failed.png"
  },
  "socket-deliverables/images/part-iii/actions-compare-success.png": {
    "title": "GitHub Actions · Successful comparison",
    "url": "library/socket-deliverables/images/part-iii/actions-compare-success.png"
  },
  "socket-deliverables/images/part-iii/actions-search-401.png": {
    "title": "GitHub Actions · Search returned 401",
    "url": "library/socket-deliverables/images/part-iii/actions-search-401.png"
  },
  "socket-deliverables/images/part-iii/cli-policy-block.png": {
    "title": "CLI policy · Block",
    "url": "library/socket-deliverables/images/part-iii/cli-policy-block.png"
  },
  "socket-deliverables/images/part-iii/cli-policy-warn.png": {
    "title": "CLI policy · Warn",
    "url": "library/socket-deliverables/images/part-iii/cli-policy-warn.png"
  },
  "socket-deliverables/integration-comparison.md": {
    "title": "Controlled GitHub App and Actions comparison",
    "url": "library/socket-deliverables/integration-comparison.html"
  },
  "socket-deliverables/lab-assets/picocolors.patch": {
    "title": "Dependency change starter patch",
    "url": "library/socket-deliverables/lab-assets/picocolors.patch"
  },
  "socket-deliverables/lab-assets/socket-ci.yml": {
    "title": "GitHub Actions starter workflow",
    "url": "library/socket-deliverables/lab-assets/socket-ci.yml"
  },
  "socket-deliverables/part-i-briefing.md": {
    "title": "Socket Technical Enablement Exercise — Part I Briefing",
    "url": "library/socket-deliverables/part-i-briefing.html"
  },
  "socket-deliverables/part-i-walkthrough.md": {
    "title": "Part I — Continuous hands-on walkthrough",
    "url": "library/socket-deliverables/part-i-walkthrough.html"
  },
  "socket-deliverables/part-ii-firewall-results.md": {
    "title": "Part II · Socket Firewall registry-mode results",
    "url": "library/socket-deliverables/part-ii-firewall-results.html"
  },
  "socket-deliverables/part-ii-firewall-workplan.md": {
    "title": "Part II — Socket Firewall live-demo workplan and capture runbook",
    "url": "library/socket-deliverables/part-ii-firewall-workplan.html"
  },
  "socket-deliverables/part-iii-lab.md": {
    "title": "Prepare a Socket demo for Widgets Mfg",
    "url": "library/socket-deliverables/part-iii-lab.html"
  },
  "socket-deliverables/part-iii-readiness-check.md": {
    "title": "Practical readiness check · Widgets Mfg demo",
    "url": "library/socket-deliverables/part-iii-readiness-check.html"
  },
  "socket-deliverables/part-iii-talk-track.md": {
    "title": "Show Courtney both Socket integration paths",
    "url": "library/socket-deliverables/part-iii-talk-track.html"
  },
  "socket-deliverables/part-iii-talk-track.pdf": {
    "title": "Widgets Mfg customer talk track (PDF)",
    "url": "library/socket-deliverables/part-iii-talk-track.pdf"
  },
  "socket-deliverables/teaching-package.md": {
    "title": "Part III · Teach it back",
    "url": "library/socket-deliverables/teaching-package.html"
  }
};
