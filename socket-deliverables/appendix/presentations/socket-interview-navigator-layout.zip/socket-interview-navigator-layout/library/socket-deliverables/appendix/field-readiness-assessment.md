# Proposed field readiness assessment · Widgets Mfg

This supplemental **50–60-minute assessment** tests readiness to advance a supervised customer POC. It extends the required [five-minute in-lab readiness check](../part-iii-readiness-check.md). The five-minute panel walkthrough below explains the design. Learner trials, timing validation, evaluator calibration, and field validation are still pending.

> **Navigator revision.** This local version updates the published assessment’s setup, evidence, and scoring expectations. The [published appendix](https://github.com/mlddragon/socket-technical-enablement-exercise/blob/main/socket-deliverables/appendix/field-readiness-assessment.md) still describes a pre-staged integration.

Foundational technical training develops the tooling, infrastructure, and workflow skills SEs need to configure, deploy, demonstrate, and troubleshoot Socket. Focused labs use previously taught prerequisites to isolate individual competencies. This integrated field assessment observes those competencies together, including independent environment preparation.

The [Part I briefing](../part-i-briefing.md) and [Part II results](../part-ii-firewall-results.md) provide the historical evidence used in the assessment. The enterprise variation is simulated.

## Assess readiness to advance a POC

### Candidate brief

> You are the SE for Widgets Mfg. Courtney wants dangerous dependencies surfaced early without making normal pull requests harder to ship. The team uses GitHub Actions and npm, and a security owner approves policy changes. Discover the team's workflow, recommend an initial Socket path, prepare a working demonstration environment on your own device, configure the chosen integration, and perform and verify a live demo, interpret a finding and a failed run, propose an appropriately scoped policy decision, and hand Courtney a POC plan. Show what you verified and what still needs testing. You may use the shared lab, talk track, product documentation, and sanitized evidence. Keep credential values off screen and do not change organization-wide policy to make a demo pass.

**Evaluator preconditions, before the clock.** Provide a customer constraint card, approved documentation and installation resources, authorized training accounts and credentials, and a dependency fixture or base repository. Stage downloads and provision external services, licenses, or access approvals that would otherwise consume the session. Provide the expected connectivity constraints and historical evidence. The base repository may contain starter assets, but the candidate must prepare their checkout and configure the chosen Socket route. Leave the case-specific local configuration and Socket integration for the candidate to set up.

**Independent setup, during the assessment.** Observe the candidate preparing their own device for the scenario. They verify versions and configure the necessary tooling and dependencies, prepare the demonstration repository and relevant integration, configure authentication and authorized access securely, and establish connectivity and certificate trust where the case requires it. They then configure Socket, run the live demo, verify the result, and troubleshoot preparation or execution issues as needed. Choose tasks relevant to the case. The simulated enterprise variation does not require a full Kubernetes, proxy, CA, and registry deployment.

If a third-party delay or access issue prevents a meaningful live observation, let the learner use saved evidence for rehearsal and record the reason. Observe independent setup and live execution in a later attempt before awarding a field-readiness pass. The separate [verification PR #2](https://github.com/mlddragon/socket-technical-enablement-exercise/pull/2) verified both integrations on one pre-authorized exercise repo. It supports discussion of the product evidence. This rubric still requires observing the candidate’s own setup and run.

### Observed tasks and artifacts (50–60 minutes)

| Time | Learner action | Required artifact or observation |
|---|---|---|
| 0–8 min | Ask Courtney about dependency sources, PR/release workflow, required checks, security ownership, acceptable friction, and POC success. Explain the value in the customer's terms. | Discovery notes, one measurable POC success criterion, and a reason for the integration choice. |
| 8–23 min | Prepare the working environment on your own device. Verify tooling and dependencies, prepare the repo, securely configure access and the chosen App or CI route, and check connectivity and certificate trust where required. Trigger the dependency change, run Socket live, verify the result in the developer view, and troubleshoot any issue that occurs. | Evaluator observation of independent device and integration setup, scenario-specific checks and safe diagnostics, and the associated repo/PR and live run or scan link/ID. Record who produced the result, package/version, outcome, and any assistance or fallback. |
| 23–38 min | Interpret the package finding separately from its effective policy. Compare the saved PyYAML Block/Warn reports; diagnose the historical 401 and the successful streaming fallback. Choose a suitable Warn/Block treatment and review scope with the security owner; explain how enforcement would be verified. | Finding and policy decision record: observed evidence, customer-specific recommendation, approver, safe verification step, and untested assumptions. |
| 38–50 min | Work the enterprise variation below. Use shared documentation before asking an expert; isolate the failed hop, collect safe evidence, state the owner and escalation boundary. | Topology annotations, prioritized checks, evidence bundle, and escalation decision. |
| 50–60 min | Give Courtney a concise update and agree on the next POC milestone and success measure. Respond to one changed condition or objection. | Customer update, POC plan, and evaluator observation of independent response. |

**Timing validation.** The assessment remains 50–60 minutes. Independent environment preparation adds work to the existing 15-minute technical slot. Pilot representative scenarios and record candidate work, external waits, and assistance separately before treating the timebox as validated.

**Policy verification boundary:** The saved Block/Warn scans demonstrate how the exercised alert type affected *those historical scans*. The current policy was returned to Inherit. A candidate can verify the historical result and present a specific proposed policy plus an authorized test plan. Mark the proposed customer's policy **not yet verified** unless an approved, isolated policy test is actually run and its outcome captured. Do not require an organization-wide policy change or suggest that changing a report visibility threshold changes enforcement.

### One enterprise variation (simulated)

Give the learner a compact topology: a Kubernetes-hosted CI runner uses an outbound proxy and internal CA; npm requests flow through Artifactory **or** Nexus and a proposed Socket Firewall route before an upstream registry. Choose **one** symptom card: TLS trust error, proxy/egress failure, registry route returning an unexpected status, or a Socket API authentication failure. Ask the learner to trace the request from developer/CI client through DNS and network path, proxy, certificate trust, registry/Firewall and upstream, then to Socket's policy decision. They should distinguish transport/authentication failures from a completed policy block, propose one safe isolation test, and name when platform, registry, security, or Socket specialists own the next step. Docker and the local Firewall result are supporting experience, not proof that this Kubernetes design works. Do not require a full implementation of every technology in one sitting.

### Behavioral scoring

Score each domain **0–4** from observed action and its artifact. Apply the same anchors across domains: **0** absent or unsafe; **1** unable to complete after a neutral prompt; **2** partially completes or needs directional help, with weak verification; **3** independently completes, cites evidence, states limits and next owner; **4** meets 3 and adapts accurately to a changed condition or objection. One neutral prompt (“What evidence would you check?”) is permitted and recorded. A substantive hint caps that domain at 2.

| Domain | What a score of 3 must show |
|---|---|
| Customer discovery and sales value | Discovers developer and security needs; explains risk reduction and developer friction; recommends a path tied to the workflow, with a falsifiable POC success criterion. |
| Technical demonstration (setup, demo, and scan) | Independently prepares a working environment on their own device. Demonstrates appropriate scenario-specific checks for tooling, repository, access and integration, and connectivity or trust as applicable. Configures Socket, executes a successful live demo, and verifies the actual package and outcome in the developer view with an identifiable run or scan. Records assistance and any troubleshooting. |
| Findings and policy judgment | Separates detection, relevance, visibility and enforcement; supports a scoped policy choice with a risk owner; verifies only what the historical or authorized sandbox evidence actually shows. |
| Enterprise troubleshooting | Traces the chosen failure across CI/CD, Docker/Kubernetes environment, DNS/network/proxy/certificate trust, registry route and supply-chain policy; checks the likely hop safely and escalates with a useful evidence bundle. |
| Independent handoff | Uses shared resources, communicates verified facts and unknowns, assigns the right owner, and advances the POC with a measurable next milestone without avoidable expert dependence. |

**Technical demonstration scoring.** A 3 requires evaluator-observed independent preparation and successful live execution. A 4 also requires accurate adaptation to a changed condition. A saved result or a demo on an already configured environment can support discussion, with a maximum of 2 in this competency until independent setup and live execution are observed. Directional help also caps the score at 2.

**Pass:** at least **16/20**, **3 or more in every domain**, and no critical fail. This is readiness for a **supervised customer POC**, not proof of deep expertise in every enterprise platform. Critical fails: disclosure of secrets; unauthorized broad policy weakening or indiscriminate bypass; asserting a failed authentication step proves malware; presenting the simulated enterprise design or an unrun policy as verified; or concealing an unresolved security/connectivity dependency in the POC handoff. If live access is unavailable, record **simulation/rehearsal completed; live execution unverified** and defer a field-readiness pass until independent setup and a successful live run are observed.

**Remediation:** Record the missed action and evidence, coach with the relevant lab section or shared runbook, then reassess that domain with a different but equivalent dependency, failure symptom, or customer constraint. A coached replay is practice; it does not replace independent reassessment. Two evaluators should independently score at least a sample and reconcile disagreements against specific actions and artifacts.

**Evaluator record:** Candidate/date; case and environment; first-take answer; provisioned resources and external waits; device/setup observations; scenario-specific configuration and checks; live or saved mode; repo/PR/run/scan link; discovery criterion; policy finding and approver; simulated symptom and checks; customer/POC update; per-domain scores and supporting observations; prompts; critical fail if any; pass or reassessment; next coach and date. Never record token values.

### Validate field impact after the exercise

Pilot the assessment with several SEs. Use equivalent **baseline and post-training** customer cases with different fixtures, the same five domains, time limits, and help rules. Check scoring agreement between evaluators and measure independent setup and run time separately from third-party waits. Have a manager observe the first real POC and follow up at 30 days: note whether the SE performed discovery, demo, policy judgment, and handoff without rescue; whether POC milestones and customer decision criteria were met; time from training to independent execution; and escalations per comparable POC split into **appropriate specialist escalations** and **avoidable requests answered by shared guidance**. Report sample size, case mix, access constraints, and support received. Do not attribute a change in these measures to training without a design that supports that causal claim.

## Five-minute panel walkthrough of the field assessment

1. **0:00–0:45:** Show Courtney's brief and the five scored actions; distinguish the five-minute in-lab demo gate from the 50–60-minute field assessment.
2. **0:45–1:45:** Show two discovery questions and a workflow-based App/CI recommendation. Point out the setup tasks the candidate must perform on their own device and the evidence the evaluator records.
3. **1:45–2:45:** Point to the real saved Block/Warn and 401/successful fallback evidence. Ask what the learner may conclude and what remains unverified.
4. **2:45–3:45:** Show the labeled simulated proxy/CA/registry symptom and the evidence and escalation expected, without presenting it as a completed deployment.
5. **3:45–5:00:** Score one example at independent 3 versus coached 2. Show the pass rule, artifact record, and how comparable cases and manager observation would test field impact.
