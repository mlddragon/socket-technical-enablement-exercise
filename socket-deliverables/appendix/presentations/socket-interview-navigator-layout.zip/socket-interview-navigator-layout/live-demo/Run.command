#!/bin/sh
set -eu

cd "$(dirname "$0")"
PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
export PATH
ACTIVITYPULSE_PYTHON="${ACTIVITYPULSE_PYTHON:-${HOME}/github/activitypulse-venv/bin/python}"
export ACTIVITYPULSE_PYTHON

if ! command -v node >/dev/null 2>&1; then
  echo 'ActivityPulse needs Node.js. Check that node is available in Terminal.' >&2
  exit 1
fi
if [ ! -x "$ACTIVITYPULSE_PYTHON" ]; then
  echo 'Select a Python environment with PyYAML 6.0.2 using ACTIVITYPULSE_PYTHON.' >&2
  exit 1
fi

node activitypulse/cli.js

if [ -t 0 ]; then
  printf '\nPress Return to finish. '
  read -r answer
fi
