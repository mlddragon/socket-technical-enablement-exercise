# ActivityPulse live change

Open this folder in Finder. Double-click **Run.command** to run the report. The launcher uses Node.js and the prepared Python environment on the interview Mac. If you use another environment, set `ACTIVITYPULSE_PYTHON` to its Python executable with PyYAML 6.0.2 installed.

1. Read the baseline. The report shows **117 total records** and five rows. Leave this first Terminal window visible.
2. Open `activitypulse/cli.js` in your editor. Directly below the line that prints the total, insert the following line and save.

   ```js
   console.log(`Activity types: ${Object.keys(summary.by_activity_type).length}`);
   ```

3. Double-click **Run.command** again. The report should show **Activity types: 5** below the total. Both windows should show the same five category counts.
4. Open a terminal in this folder and run `diff -u baseline.js activitypulse/cli.js`. It should show one added line. A diff exit status of 1 means the two files differ.
5. To repeat the exercise, remove the line you added, save the file, and rerun the diff. An empty diff confirms the original CLI is restored.

The rehearsal copy comes from exercise commit `9abc3d6`. The reference copy of the CLI is `baseline.js`.
