'use strict';
// Presenter-only commands. Braced paths are resolved relative to the opened Layout folder.
window.COMMANDS = [
  {
    "sections": [
      0,
      1
    ],
    "slides": [
      "Organization Access",
      "Establishing baseline"
    ],
    "title": "Check the installed Socket CLI",
    "kind": "Inspect",
    "command": "socket --version",
    "note": "The exercise was captured on Node CLI version 1.15.0."
  },
  {
    "sections": [
      0
    ],
    "slides": [
      "Organization Access"
    ],
    "title": "Install the Socket CLI",
    "kind": "Local change",
    "command": "npm install -g socket",
    "note": "Install this only if it is missing. It changes the global npm tools on this computer."
  },
  {
    "sections": [
      0,
      1
    ],
    "slides": [
      "Organization Access",
      "CLI Permissions"
    ],
    "title": "Sign in with an organization API token",
    "kind": "Sign-in",
    "command": "socket login --api-token",
    "note": "Use the hidden prompt with screen sharing paused. The token value is never part of this command."
  },
  {
    "sections": [
      0,
      1
    ],
    "slides": [
      "CLI Permissions",
      "Establishing baseline"
    ],
    "title": "Inspect scan flags and scope hints",
    "kind": "Inspect",
    "command": "socket scan create --help --no-banner\nsocket scan report --help --no-banner",
    "note": "Compare CLI help with the Permissions Explorer and the behavior observed in the exercise."
  },
  {
    "sections": [
      1
    ],
    "slides": [
      "Establishing baseline"
    ],
    "title": "Inspect ActivityPulse manifests",
    "kind": "Inspect",
    "command": "cd \"$HOME/github/socket-technical-enablement-exercise\" && git ls-files -- \"*package.json\" \"*requirements.txt\"",
    "note": "Check which manifests are in the current checkout. Use the saved report for the historical baseline before third-party dependencies."
  },
  {
    "sections": [
      1
    ],
    "slides": [
      "Establishing baseline"
    ],
    "title": "List existing full scans",
    "kind": "API read",
    "command": "socket scan list --no-banner",
    "note": "Use this to recover a scan ID without creating another scan."
  },
  {
    "sections": [
      1
    ],
    "slides": [
      "Establishing baseline"
    ],
    "title": "Inspect saved baseline metadata",
    "kind": "API read",
    "command": "socket scan metadata ea295308-005a-4aeb-87f4-f525861e2fb4 --json --no-banner",
    "note": "Requires access to the exercise organization. Metadata shows scan completion, while the report shows policy health."
  },
  {
    "sections": [
      1
    ],
    "slides": [
      "Establishing baseline"
    ],
    "title": "Read the saved baseline report",
    "kind": "API read",
    "command": "socket scan report ea295308-005a-4aeb-87f4-f525861e2fb4 --json --fold=version --no-banner",
    "note": "Shows the original empty dependency inventory. Use bundled evidence if access has expired."
  },
  {
    "sections": [
      1
    ],
    "slides": [
      "Establishing baseline"
    ],
    "title": "Create a fresh scan on an isolated demo branch",
    "kind": "Creates scan",
    "command": "(\n  cd \"$HOME/github/socket-technical-enablement-exercise\" || exit 1\n  socket scan create --repo=socket-technical-enablement-exercise \\\n    --branch=interview-live-demo --report --no-banner .\n  printf 'Socket process exit: %s\\n' \"$?\"\n)",
    "note": "Uploads the current manifests and records a new scan under interview-live-demo in the authenticated organization. Use only in the authorized exercise organization."
  },
  {
    "sections": [
      1,
      3
    ],
    "slides": [
      "Applying Policy",
      "Full Experiment",
      "Troubleshooting & Enforcement"
    ],
    "title": "Read the saved Block report",
    "kind": "API read",
    "command": "socket scan report 1a1190d3-8b85-4692-9f01-310c3cc406bf --json --fold=version --no-banner",
    "note": "Look for healthy: false and policy: error. Original scan-and-report exited 1."
  },
  {
    "sections": [
      1,
      3
    ],
    "slides": [
      "Applying Policy",
      "Full Experiment",
      "Troubleshooting & Enforcement"
    ],
    "title": "Read the saved Warn report",
    "kind": "API read",
    "command": "socket scan report 46093b05-bcd0-438a-9592-4e2a8f045ef3 --json --fold=version --report-level=warn --no-banner",
    "note": "Look for healthy: true and policy: warn. Original scan-and-report exited 0."
  },
  {
    "sections": [
      1,
      3
    ],
    "slides": [
      "Configure integration",
      "Socket GitHub App"
    ],
    "title": "Inspect PR #1 checks and comments",
    "kind": "API read",
    "command": "gh pr checks 1 --repo mlddragon/socket-technical-enablement-exercise\ngh pr view 1 --repo mlddragon/socket-technical-enablement-exercise --comments",
    "note": "Show where each integration reported on the historical PR."
  },
  {
    "sections": [
      1,
      3
    ],
    "slides": [
      "Configure integration",
      "GitHub Actions",
      "Troubleshooting & Enforcement"
    ],
    "title": "Read the historical Actions job",
    "kind": "API read",
    "command": "gh run view 44557864628 --repo mlddragon/socket-technical-enablement-exercise --job 135696762163 --log",
    "note": "Find the streaming comparison fallback and check the final result. GitHub may expire old logs."
  },
  {
    "sections": [
      1,
      3
    ],
    "slides": [
      "GitHub Actions",
      "Troubleshooting & Enforcement"
    ],
    "title": "Read the original failing Actions job",
    "kind": "API read",
    "command": "gh run view 44557864628 --repo mlddragon/socket-technical-enablement-exercise --job 135678730253 --log-failed",
    "note": "Use the saved screenshot if the log has expired. HTTP 401 and exit 3 occurred before dependency analysis."
  },
  {
    "sections": [
      2
    ],
    "slides": [
      "Setup and configuration"
    ],
    "title": "Check Docker and npm versions",
    "kind": "Inspect",
    "command": "docker --context colima version\ndocker --context colima compose version\nnpm --version",
    "note": "Confirms the client and local container engine before discussing the registry deployment."
  },
  {
    "sections": [
      2
    ],
    "slides": [
      "Setup and configuration"
    ],
    "title": "Check Firewall status and TLS health",
    "kind": "Inspect",
    "command": "cd \"$HOME/socket-fw-demo\" &&\n  docker --context colima compose ps &&\n  curl --noproxy '*' --cacert ssl/fullchain.pem \\\n    -sS -o /dev/null -w 'Health: HTTP %{http_code}\\n' https://localhost:8443/health",
    "note": "Expect HTTP 200 for the local service. The scoped CA preserves certificate verification."
  },
  {
    "sections": [
      2
    ],
    "slides": [
      "Setup and configuration"
    ],
    "title": "Start Colima if the engine is stopped",
    "kind": "Local change",
    "command": "colima status || colima start",
    "note": "Use on the prepared Mac if the Docker check reports that its engine is unavailable."
  },
  {
    "sections": [
      2
    ],
    "slides": [
      "Setup and configuration"
    ],
    "title": "Start the prepared Firewall service",
    "kind": "Local change",
    "command": "cd \"$HOME/socket-fw-demo\" && docker --context colima compose up -d",
    "note": "Starts the existing configuration. Run the health check again before relying on it."
  },
  {
    "sections": [
      2
    ],
    "slides": [
      "Setup and configuration"
    ],
    "title": "Inspect recent Firewall startup logs",
    "kind": "Inspect",
    "command": "cd \"$HOME/socket-fw-demo\" && docker --context colima compose logs --tail=100 | grep -Ei \"resolved org slug|listen|error\"",
    "note": "Look for organization lookup and startup. Keep the raw logs private if they contain environment details."
  },
  {
    "sections": [
      2
    ],
    "slides": [
      "Setup and configuration"
    ],
    "title": "Check the npm registry route for picocolors",
    "kind": "Inspect",
    "command": "cd \"$HOME/socket-fw-demo\" &&\n  curl --noproxy '*' --cacert ssl/fullchain.pem -sS -o /dev/null \\\n    -w 'Package metadata: HTTP %{http_code}\\n' https://localhost:8443/npm/picocolors",
    "note": "Requests public package metadata through the demo registry. A 200 here tests routing."
  },
  {
    "sections": [
      2
    ],
    "slides": [
      "Applying Policy"
    ],
    "title": "Repeat the allowed install in a fresh fixture",
    "kind": "Temporary local install",
    "command": "(\n  set -e\n  demo_tmp=$(mktemp -d)\n  cd \"$demo_tmp\"\n  npm init -y >/dev/null\n  npm install --registry=https://localhost:8443/npm/ \\\n    --cafile=\"$HOME/socket-fw-demo/ssl/fullchain.pem\" \\\n    --strict-ssl=true --cache=\"$demo_tmp/cache\" \\\n    --ignore-scripts --no-audit --no-fund lodash@4.17.21\n  printf 'Temporary demo fixture: %s\\n' \"$demo_tmp\"\n)",
    "note": "Exercises the same allowed package through Firewall using a separate cache and a scoped CA. Use saved evidence for the blocked case."
  },
  {
    "sections": [
      2
    ],
    "slides": [
      "Applying Policy"
    ],
    "title": "Read the captured allowed decision",
    "kind": "Saved evidence",
    "command": "cd \"$HOME/socket-fw-demo\" &&\n  jq '{decision, action, monitor_reason, response_code, upstream_status, cached}' capture/P03-allowed-decision.json",
    "note": "Look for decision: allowed, action: monitor and response_code: 200."
  },
  {
    "sections": [
      2
    ],
    "slides": [
      "Applying Policy"
    ],
    "title": "Compare the saved HTTP check and original npm decision",
    "kind": "Saved evidence",
    "command": "cd \"$HOME/socket-fw-demo\" &&\n  printf '%s\\n' 'P05 · Direct HTTP requests' &&\n  awk '/^x-socket-request-id:/ {sub(/\\r$/, \"\", $2); printf \"%s %s…%s\\n\", $1, substr($2,1,4), substr($2,length($2)-3); next}\n       /^\\/npm\\/|^HTTP\\/|^x-socket-(decision|block-reason):/ {print}' capture/P05-http-verdict-headers.txt &&\n  printf '%s\\n' 'P06 · Original npm decision' &&\n  jq '{request_id:(.request_id | .[0:4] + \"…\" + .[-4:]), source_path, decision, block_reason, response_code, cached}' capture/P06-matching-decision-log.json",
    "note": "P05 is the separate HTTP check. P06 is the original npm decision and shows the npm request ID in masked form."
  },
  {
    "sections": [
      2
    ],
    "slides": [
      "Setup and configuration"
    ],
    "title": "Check the fixture’s effective npm registry",
    "kind": "Inspect",
    "command": "cd \"$HOME/socket-fw-demo/allow\" && npm config get registry",
    "note": "Read the registry for the prepared fixture. Expect https://localhost:8443/npm/."
  },
  {
    "sections": [
      2
    ],
    "slides": [
      "Setup and configuration"
    ],
    "title": "Inspect the scoped local TLS certificate",
    "kind": "Inspect",
    "command": "openssl x509 -in \"$HOME/socket-fw-demo/ssl/fullchain.pem\" -noout -subject -dates -text |\n  awk '/^subject=|^notBefore=|^notAfter=/{print} /Subject Alternative Name/{print; getline; print}'",
    "note": "Check the certificate’s validity dates and localhost SAN. The certificate is public and the command does not print the private key."
  },
  {
    "sections": [
      2
    ],
    "slides": [
      "Setup and configuration"
    ],
    "title": "Confirm the normal npm registry outside the fixtures",
    "kind": "Inspect",
    "command": "cd \"$HOME\" && npm config get registry",
    "note": "Shows the user registry remains unchanged outside the demo project directories."
  },
  {
    "sections": [
      3,
      4
    ],
    "slides": [
      "GitHub Actions",
      "Troubleshooting & Enforcement",
      "Hands-on Lab"
    ],
    "title": "Check GitHub CLI sign-in",
    "kind": "Inspect",
    "command": "gh auth status",
    "note": "Check that the active GitHub account has access to both training repositories."
  },
  {
    "sections": [
      3,
      4
    ],
    "slides": [
      "GitHub Actions",
      "Troubleshooting & Enforcement",
      "Socket GitHub App",
      "Hands-on Lab"
    ],
    "title": "Check both local training clones and downloads",
    "kind": "Inspect",
    "command": "(\n  for repo in \"$HOME/github/widgets-ci\" \"$HOME/github/widgets-app\"; do\n    git -C \"$repo\" status --short --branch || exit 1\n    git -C \"$repo\" remote get-url origin || exit 1\n  done\n  ls -l \"$HOME/Downloads/picocolors.patch\" \"$HOME/Downloads/socket-ci.yml\"\n)",
    "note": "The folder names match the lab. Check the remotes before using a block that pushes."
  },
  {
    "sections": [
      3,
      4
    ],
    "slides": [
      "Hands-on Lab"
    ],
    "title": "Apply the same patch to both training clones",
    "kind": "Local change",
    "command": "(\n  set -e\n  lab_ci_repo=\"$HOME/github/widgets-ci\"\n  lab_app_repo=\"$HOME/github/widgets-app\"\n  lab_patch=\"$HOME/Downloads/picocolors.patch\"\n  lab_actions_starter=\"$HOME/Downloads/socket-ci.yml\"\n  : \"${lab_ci_repo:?Set lab_ci_repo using the path block above.}\"\n  : \"${lab_app_repo:?Set lab_app_repo using the path block above.}\"\n  : \"${lab_patch:?Set lab_patch using the path block above.}\"\n  for lab_repo in \"$lab_ci_repo\" \"$lab_app_repo\"; do\n    printf '\\n%s\\n' \"$lab_repo\"\n    lab_branch=$(git -C \"$lab_repo\" branch --show-current)\n    if [ \"$lab_branch\" = demo/add-picocolors ] &&\n      git -C \"$lab_repo\" apply --reverse --check \"$lab_patch\" 2>/dev/null; then\n      printf 'Patch already applied.\\n'\n    else\n      git -C \"$lab_repo\" apply --check \"$lab_patch\"\n      if [ \"$lab_branch\" != demo/add-picocolors ]; then\n        git -C \"$lab_repo\" switch -c demo/add-picocolors\n      fi\n      git -C \"$lab_repo\" apply \"$lab_patch\"\n    fi\n    git -C \"$lab_repo\" diff --stat\n  done\n  printf '\\nBoth clones are patched. Next: A · GitHub Actions.\\n'\n)",
    "note": "Run only in the two training clones. This selects or creates demo/add-picocolors and applies the supplied patch."
  },
  {
    "sections": [
      3,
      4
    ],
    "slides": [
      "GitHub Actions",
      "Troubleshooting & Enforcement",
      "Hands-on Lab"
    ],
    "title": "Check the Actions secret name",
    "kind": "API read",
    "command": "gh secret list --repo mlddragon/widgets-ci --app actions",
    "note": "The list shows names. Look for SOCKET_SECURITY_API_KEY."
  },
  {
    "sections": [
      3,
      4
    ],
    "slides": [
      "GitHub Actions",
      "Troubleshooting & Enforcement"
    ],
    "title": "Set the training Actions secret",
    "kind": "Changes GitHub settings",
    "command": "gh secret set SOCKET_SECURITY_API_KEY --repo mlddragon/widgets-ci --app actions",
    "note": "Use only if authorized and the training secret is missing. Paste into the hidden prompt with screen sharing paused."
  },
  {
    "sections": [
      3,
      4
    ],
    "slides": [
      "GitHub Actions",
      "Troubleshooting & Enforcement",
      "Hands-on Lab"
    ],
    "title": "Commit and push the Actions demo branch",
    "kind": "Pushes to GitHub",
    "command": "(\n  set -e\n  lab_ci_repo=\"$HOME/github/widgets-ci\"\n  lab_app_repo=\"$HOME/github/widgets-app\"\n  lab_patch=\"$HOME/Downloads/picocolors.patch\"\n  lab_actions_starter=\"$HOME/Downloads/socket-ci.yml\"\n  : \"${lab_ci_repo:?Set lab_ci_repo using the path block above.}\"\n  : \"${lab_actions_starter:?Set lab_actions_starter using the path block above.}\"\n  if [ ! -f \"$lab_actions_starter\" ]; then\n    printf 'Workflow starter not found at %s\\n' \"$lab_actions_starter\" >&2\n    exit 1\n  fi\n  cd \"$lab_ci_repo\"\n  test \"$(git branch --show-current)\" = demo/add-picocolors\n  mkdir -p .github/workflows\n  cp \"$lab_actions_starter\" .github/workflows/socket.yml\n  git add prod/cli.js prod/package.json prod/package-lock.json .github/workflows/socket.yml\n  git diff --cached --name-only\n  git commit -m \"Demo dependency change with Socket Actions\"\n  git push -u origin demo/add-picocolors\n  printf '\\nCI branch pushed. Next: B · Socket GitHub App.\\n'\n)",
    "note": "Use after applying the patch and checking the Actions secret. Targets the CI clone."
  },
  {
    "sections": [
      3,
      4
    ],
    "slides": [
      "Socket GitHub App",
      "Hands-on Lab"
    ],
    "title": "Commit and push the App demo branch",
    "kind": "Pushes to GitHub",
    "command": "(\n  set -e\n  lab_ci_repo=\"$HOME/github/widgets-ci\"\n  lab_app_repo=\"$HOME/github/widgets-app\"\n  lab_patch=\"$HOME/Downloads/picocolors.patch\"\n  lab_actions_starter=\"$HOME/Downloads/socket-ci.yml\"\n  : \"${lab_app_repo:?Set lab_app_repo using the path block above.}\"\n  cd \"$lab_app_repo\"\n  test \"$(git branch --show-current)\" = demo/add-picocolors\n  git add prod/cli.js prod/package.json prod/package-lock.json\n  git diff --cached --name-only\n  git commit -m \"Demo dependency change with the Socket GitHub App\"\n  git push -u origin demo/add-picocolors\n  printf '\\nApp branch pushed. Next: Open one PR in each training repo.\\n'\n)",
    "note": "Confirm the Socket GitHub App can access this repository first. Targets the App clone."
  },
  {
    "sections": [
      3,
      4
    ],
    "slides": [
      "Hands-on Lab"
    ],
    "title": "Find or open the two training PRs",
    "kind": "May create PRs",
    "command": "(\n  set -e\n  lab_ci_repo=\"$HOME/github/widgets-ci\"\n  lab_app_repo=\"$HOME/github/widgets-app\"\n  lab_patch=\"$HOME/Downloads/picocolors.patch\"\n  lab_actions_starter=\"$HOME/Downloads/socket-ci.yml\"\n  : \"${lab_ci_repo:?Set lab_ci_repo using the path block above.}\"\n  : \"${lab_app_repo:?Set lab_app_repo using the path block above.}\"\n  lab_head=demo/add-picocolors\n  for lab_repo in \"$lab_ci_repo\" \"$lab_app_repo\"; do\n    cd \"$lab_repo\"\n    lab_origin=$(git remote get-url origin)\n    lab_slug=$(gh repo view \"$lab_origin\" --json nameWithOwner --jq '.nameWithOwner')\n    lab_base=$(gh repo view \"$lab_origin\" --json defaultBranchRef --jq '.defaultBranchRef.name')\n    lab_pr=$(gh pr list --repo \"$lab_slug\" --base \"$lab_base\" --head \"$lab_head\" \\\n      --state open --limit 1 --json url --jq '.[0].url // empty')\n    printf '%s\\n' \"$lab_slug\"\n    if [ -n \"$lab_pr\" ]; then\n      printf '%s\\n' \"$lab_pr\"\n    else\n      gh pr create --repo \"$lab_slug\" --base \"$lab_base\" --head \"$lab_head\" \\\n        --title 'Demo dependency change with picocolors' \\\n        --body 'Add picocolors to ActivityPulse for the Widgets Mfg Socket demo.'\n    fi\n  done\n  printf '\\nBoth PRs are open. Next: 10–18 minutes · Verify the engineer’s view.\\n'\n)",
    "note": "Use after both branches are pushed. Existing open PRs are reused."
  },
  {
    "sections": [
      3,
      4
    ],
    "slides": [
      "GitHub Actions",
      "Troubleshooting & Enforcement"
    ],
    "title": "List recent training Actions runs",
    "kind": "API read",
    "command": "gh run list --repo mlddragon/widgets-ci --branch demo/add-picocolors --event pull_request --limit 5",
    "note": "Find the run for the training PR. The saved WidgetsT1 job is separate evidence from an earlier run-through."
  },
  {
    "sections": [
      3,
      4
    ],
    "slides": [
      "Socket GitHub App"
    ],
    "title": "Find the training App pull request",
    "kind": "API read",
    "command": "gh pr list --repo mlddragon/widgets-app --head demo/add-picocolors --state open --limit 5",
    "note": "Use the returned PR number to locate the Socket check and comment in GitHub."
  },
  {
    "sections": [
      5
    ],
    "slides": [
      "Live Demonstration",
      "Implementation & Verification"
    ],
    "title": "Run the bundled ActivityPulse demo",
    "kind": "Inspect",
    "command": "cd {{liveDemo}} && ./Run.command",
    "note": "Uses the prepared Python environment. The bundled CSV contains 117 records."
  },
  {
    "sections": [
      5
    ],
    "slides": [
      "Live Demonstration",
      "Implementation & Verification"
    ],
    "title": "Open the editable CLI file",
    "kind": "Editor",
    "command": "open -e {{cliFile}}",
    "note": "Opens the rehearsal copy in TextEdit. The slide shows the one-line change to make."
  },
  {
    "sections": [
      5
    ],
    "slides": [
      "Implementation & Verification"
    ],
    "title": "Check what changed in the demo CLI",
    "kind": "Inspect",
    "command": "cd {{liveDemo}} && diff -u baseline.js activitypulse/cli.js",
    "note": "A diff with one added line is the expected changed result. An empty diff means the rehearsal file matches the baseline."
  },
  {
    "sections": [
      5
    ],
    "slides": [
      "Implementation & Verification"
    ],
    "title": "Check Node syntax before rerunning",
    "kind": "Inspect",
    "command": "node --check {{cliFile}}",
    "note": "No output means the syntax check passed. Run ActivityPulse to verify behavior."
  }
];
