#!/bin/sh
cd "$(dirname "$0")" || exit 1
open -a "Google Chrome" "$PWD/index.html" || open "$PWD/index.html"
