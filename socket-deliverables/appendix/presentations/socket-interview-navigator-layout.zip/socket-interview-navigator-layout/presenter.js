'use strict';
const storageKey='socket-navigator-layout-v6';
let state={index:0,ref:null,tab:'notes',trail:[],elapsed:0,started:0,token:Math.random().toString(36).slice(2)};
try{
 const saved=JSON.parse(sessionStorage.getItem(storageKey));
 if(saved){
   Object.assign(state,saved);
 }else{
   const revisedTeach=JSON.parse(sessionStorage.getItem('socket-navigator-layout-v5'));
   const expanded=JSON.parse(sessionStorage.getItem('socket-navigator-layout-v4'));
   const previous=JSON.parse(sessionStorage.getItem('socket-navigator-layout-v3'));
   const timed=JSON.parse(sessionStorage.getItem('socket-navigator-layout-v2'));
   const earlier=revisedTeach||expanded||previous||timed||JSON.parse(sessionStorage.getItem('socket-navigator-layout-v1'));
   if(earlier){
     const firstFirewallTopic=deck.findIndex(slide=>slide.section===2&&!slide.cover);
     const addedFirewallTopics=deck.filter(slide=>slide.section===2&&!slide.cover).length-1;
     const removedTopic=deck.findLastIndex(slide=>slide.section===3)+1;
     const talkTrackIndex=deck.findIndex(slide=>slide.section===4&&slide.short==='Customer Talk Track');
     const mapIndex=index=>{
       if(!revisedTeach){
         if(!expanded&&!previous&&!timed)index+=(index>=4?1:0)+(index>=7?1:0);
         if(!expanded&&!previous&&index>=8)index++;
         if(!expanded&&index>firstFirewallTopic)index+=addedFirewallTopics;
         if(index>=removedTopic)index--;
       }
       return index+(index>=talkTrackIndex?1:0);
     };
     Object.assign(state,earlier,{index:mapIndex(earlier.index),trail:earlier.trail.map(entry=>({...entry,index:mapIndex(entry.index)}))});
   }
 }
}catch{}
if(!deck[state.index])state.index=0;
if(!catalog[state.ref] || catalog[state.ref].kind==='live')state.ref=null;
let readerScroll=0, expanded=[], mirrorEvidence=false;
let audience=null, lastHello=0, openedAt=0, rendered=null, refreshedWindow=null;
let mode='all', liveStarted=false, connectedByChannel=false;
const reconnectChannel=typeof BroadcastChannel==='function'?new BroadcastChannel('socket-audience-'+state.token):null;
const liveEntry=()=>catalog[state.ref]?.kind==='live'?catalog[state.ref]:null;
const audienceTimeout=7000;
const audienceFeatures='popup,width=1220,height=765,resizable=yes';
function audiencePage(){return './audience.html?v='+audienceProtocol+'#'+state.token;}
function audienceConnected(){return Boolean((connectedByChannel || (audience&&!audience.closed))&&lastHello&&Date.now()-lastHello<audienceTimeout);}
function audienceMatches(message){return message?.index===state.index&&(message.ref??null)===state.ref;}

function sendToAudience(data){
 if(connectedByChannel && audienceConnected())reconnectChannel.postMessage(data);
 else if(audience && !audience.closed)audience.postMessage(data,'*');
}
let pendingPlay=false, clipStatus='';
function controlClip(action){
 if(action==='pause')pendingPlay=false;
 if(!deck[state.index].video || state.ref)return;
 if(action==='play' && !openAudience())return;
 if((!audience || audience.closed) && !audienceConnected())return;
 if(action==='play' && !audienceConnected()){pendingPlay=true;return;}
 transmit();
 sendToAudience({kind:'socket-video',token:state.token,index:state.index,action});
}
function save(){try{sessionStorage.setItem(storageKey,JSON.stringify(state));}catch{}}
function transmit(){if(!liveEntry())sendToAudience({kind:'socket-slide',token:state.token,index:state.index,ref:state.ref,mirrorEvidence,scroll:readerScroll,expanded});}
function go(i,jump=false,tab='notes'){
  if(!deck[i])return;
  if(jump && i!==state.index)state.trail.push({index:state.index,tab:state.tab});
  returnFromLive();
  pendingPlay=false;clipStatus='';
 state.index=i;state.ref=null;mirrorEvidence=false;state.tab=tab;render();
}
function previousTopic(){const old=state.trail.pop();if(old)go(old.index,false,old.tab);}
function openAudience(force=false){
 if(!force && connectedByChannel && audienceConnected())return true;
 const hasWindow=audience&&!audience.closed;
 if(force||!hasWindow||(!audienceConnected()&&Date.now()-openedAt>=audienceTimeout)){
   lastHello=0;
   connectedByChannel=false;
   rendered=null;
   openedAt=Date.now();
   refreshedWindow=null;
   audience=window.open(audiencePage(),'socket_audience_'+state.token,audienceFeatures);
 }
 byId('message').textContent=audience?'':'Allow pop-ups for the navigator and click the evidence title again to present it.';
 return Boolean(audience);
}
function navigateLive(){
 const entry=liveEntry();
 if(!entry || liveStarted || !audienceConnected())return;
 sendToAudience({kind:'socket-live',token:state.token,url:entry.url});
 liveStarted=true;
 lastHello=0;
 updateAudience();
}
function returnFromLive(){
 if(!liveStarted)return;
 liveStarted=false;
 if(audience && !audience.closed){
   audience.location.replace(new URL(audiencePage(),location.href).href);
   openedAt=Date.now();
 }else{
   byId('message').textContent='Use Back in the shared audience window to return to the deck. If needed, open a new audience window and share it.';
 }
 lastHello=0;
 rendered=null;
}
function showRef(ref){
 const entry=catalog[ref];
 if(!entry)return;
 if(liveStarted && entry.kind!=='live')returnFromLive();
 const wasLive=liveStarted && audience && !audience.closed;
 const canNavigate=audienceConnected();
 if(!wasLive && !openAudience())return;
 readerScroll=0;expanded=[];mirrorEvidence=false;state.ref=ref;
 if(wasLive && entry.kind==='live'){
   audience.location.href=entry.url;
 }else{
   liveStarted=false;
   if(canNavigate)navigateLive();
 }
 render();
}
function closeRef(){returnFromLive();state.ref=null;mirrorEvidence=false;render();}
function pageEvidence(direction){
 const reader=byId('deskReference').querySelector('.reader');
 if(reader)reader.scrollBy(0,direction*reader.clientHeight*.82);
 else sendToAudience({kind:'socket-page',token:state.token,ref:state.ref,direction});
}
function updateAudience(){
 const active=audienceConnected();
 const hasWindow=active||Boolean(audience&&!audience.closed);
 if(liveStarted){
   byId('connection').textContent='Audience switched to live site';
   byId('launch').textContent=hasWindow?'Focus audience window ↗':'Return from live site';
   byId('evidenceTitle').textContent='Live page sent to audience · '+shortTitle(state.ref);
   byId('evidencePending').hidden=true;
   return;
 }
 byId('connection').textContent=active?'● Audience connected':hasWindow?'Waiting for audience':'Audience window closed';
 byId('launch').textContent=active?'Focus audience window ↗':hasWindow?'Reconnect audience ↗':'Open audience window ↗';
 if(state.ref){
   const confirmed=active&&audienceMatches(rendered);
   byId('evidenceTitle').textContent=(confirmed?'Audience evidence · ':'Waiting to present · ')+shortTitle(state.ref);
   byId('evidencePending').hidden=confirmed;
 }
}
byId('launch').onclick=()=>{
 if(liveStarted){
   if(audience && !audience.closed)audience.focus();
   else closeRef();
   return;
 }
 if(!audienceConnected())openedAt=0;
 if(openAudience()){
   if(connectedByChannel)sendToAudience({kind:'socket-focus',token:state.token});
   else if(audience && !audience.closed)audience.focus();
   transmit();
 }
};
function hearAudience(e,viaChannel=false){
 if(!e.data||e.data.token!==state.token||(!viaChannel&&!e.source))return;
 if(!viaChannel && location.protocol!=='file:'&&e.origin!==location.origin)return;
 if(!viaChannel && audience&&!audience.closed&&e.source!==audience)return;
 if(e.data.kind==='socket-reader-position'){
   if((viaChannel||e.source===audience) && !mirrorEvidence && state.ref===e.data.ref){
     readerScroll=Math.max(0,Math.min(1,Number(e.data.scroll)||0));
     expanded=Array.isArray(e.data.expanded)?e.data.expanded:[];
   }
   return;
 }
 if(e.data.kind==='socket-video-status'){
   if((viaChannel||e.source===audience) && e.data.index===state.index && !state.ref && byId('clipStatus')){
     clipStatus=String(e.data.label);byId('clipStatus').textContent=clipStatus;
   }
   return;
 }
 if(e.data.kind==='socket-rendered'){
   if((viaChannel||e.source===audience)&&e.data.protocol===audienceProtocol){
     rendered=e.data;lastHello=Date.now();updateAudience();
   }
   return;
 }
 if(e.data.kind!=='socket-ready')return;
 const newConnection=viaChannel!==connectedByChannel || (!viaChannel && audience!==e.source);
 if(!viaChannel)audience=e.source;
 connectedByChannel=viaChannel;
 if(e.data.protocol!==audienceProtocol){
   if(viaChannel)return;
   if(refreshedWindow!==audience){
     refreshedWindow=audience;
     openedAt=Date.now();lastHello=0;rendered=null;
     audience.location.replace(new URL(audiencePage(),location.href).href);
     updateAudience();
   }
   return;
 }
 lastHello=Date.now();
 rendered=e.data;
 if(e.data.returnedFromLive){
   liveStarted=false;
   if(liveEntry())state.ref=null;
   byId('message').textContent='';
   render();
   return;
 }
 updateAudience();
 if(liveEntry()){
   if(!liveStarted)navigateLive();
   return;
 }
 if(newConnection||!audienceMatches(e.data))transmit();
 if(pendingPlay){pendingPlay=false;controlClip('play');}
}
window.addEventListener('message',event=>hearAudience(event));
reconnectChannel?.addEventListener('message',event=>hearAudience(event,true));
const retinaWidth=1512;
const previewFrame=byId('retinaPreview');
new ResizeObserver(([entry])=>{
 const scale=entry.contentRect.width/retinaWidth;
 previewFrame.style.transform='scale('+scale+')';
 const sourcebox=byId('sourceHeading').closest('aside');
 sourcebox.style.setProperty('--preview-height',entry.contentRect.height+'px');
}).observe(byId('stage'));
function renderPreview(slide){
 const showingReference=Boolean(mirrorEvidence && state.ref);
 previewFrame.hidden=showingReference;
 const reference=byId('deskReference');
 reference.hidden=!showingReference;
 reference.innerHTML=showingReference?referenceView(state.ref):'';
 byId('deskClip').hidden=!slide.video || showingReference;
 if(showingReference)return;
 // Use the same markup and stylesheet as the audience view at its fullscreen viewport.
 let markup=board(state.index,null,Boolean(slide.extras||slide.image));
 if(slide.video){
   const template=document.createElement('template');
   template.innerHTML=markup;
   const video=template.content.querySelector('video');
   const poster=document.createElement('img');
   poster.src=video.getAttribute('poster');
   poster.alt='Courtney on the Widgets Mfg call';
   poster.className='preview-video-poster';
   video.replaceWith(poster);
   markup=template.innerHTML;
 }
 previewFrame.srcdoc='<!doctype html><html lang="en"><head><meta charset="utf-8"><link rel="stylesheet" href="'+safe(new URL('style.css',location.href).href)+'"></head><body class="audience desk-preview"><main id="stage">'+markup+'</main></body></html>';
}
previewFrame.addEventListener('load',()=>{
 const doc=previewFrame.contentDocument;
 if(!doc)return;
 doc.addEventListener('click',e=>{
   const item=e.target.closest('[data-ref]');
   if(item)showRef(item.dataset.ref);
   if(e.target.closest('[data-commands]'))openCommands();
 });
 doc.addEventListener('keydown',handleShortcuts);
});
function sourceLink(path){
 const ref=catalog[path];
 if(!ref)return externalLink({url:githubSnapshot+path,title:shortTitle(path)});
 return '<div class="source-row"><button class="source-title" data-ref="'+safe(path)+'" title="Show in audience window">'+safe(shortTitle(path))+'<span aria-hidden="true">Present →</span></button></div>';
}
function externalLink(link){
 const title=safe(link.title);
 const action=link.url.startsWith('https:')
   ? '<button class="source-title" data-ref="'+safe(liveKey(link.url))+'">'+title+'<span aria-hidden="true">Audience ↗</span></button>'
   : '<a class="source-title" target="_blank" rel="noopener" href="'+safe(link.url)+'">'+title+'<span aria-hidden="true">Files ↗</span></a>';
 return '<div class="source-row">'+action+'</div>';
}
const appendix=deck.at(-1).extras;
const permissionsRef=appendix.find(item=>item.label==='CLI Permissions Explorer').ref;
const quickRefs=[
 'socket-deliverables/images/part-iii/cli-policy-block.png',
 'socket-deliverables/appendix/videos/socket-demo-screen-only-review.mp4'
];
function render(){
 const s=deck[state.index];
 byId('welcomeBtn').setAttribute('aria-current',s.welcome?'step':'false');
 byId('extrasBtn').setAttribute('aria-current',s.extras?'step':'false');
 byId('deskDetails').hidden=Boolean(s.extras);

 byId('outline').innerHTML=SECTIONS.map((sec,n)=>{
   const first=deck.findIndex(d=>d.section===n);
   const current=n===(s.welcome?0:s.section);
   const kids=current&&!s.welcome?'<div class="section-list">'+deck.map((d,i)=>d.section===n&&!d.cover?'<button class="topic '+(state.index===i?'active':'')+'" data-slide="'+i+'" '+(state.index===i?'aria-current="step"':'')+'>'+safe(d.short)+'</button>':'').join('')+'</div>':'';
   return '<button class="section-btn '+(current?'current':'')+'" style="--chapter-col:'+(n+1)+'" data-slide="'+first+'" aria-expanded="'+(current&&!s.welcome)+'" '+(s.cover&&current?'aria-current="step"':'')+'><span class="idx">'+sectionNumber(n)+'</span><span>'+safe(sec.name)+'<small>'+formatTime(sec.duration)+' · '+sectionWindow(sec)+'</small></span></button>'+kids;
 }).join('');
 renderPreview(s);
 const reader=byId('deskReference').querySelector('.reader');
 if(reader){
   const details=[...reader.querySelectorAll('details')];
   details.forEach((el,k)=>{el.open=expanded.includes(k);});
   reader.scrollTop=readerScroll*Math.max(0,reader.scrollHeight-reader.clientHeight);
   reader.addEventListener('scroll',()=>{readerScroll=reader.scrollTop/Math.max(1,reader.scrollHeight-reader.clientHeight);transmit();},{passive:true});
   reader.addEventListener('toggle',()=>{expanded=details.flatMap((el,k)=>el.open?[k]:[]);transmit();},true);
 }
 byId('clipStatus').textContent=clipStatus;
 byId('evidenceBar').hidden=!state.ref;
 if(state.ref){
   byId('pageControls').hidden=!window.REF_TEXT[state.ref];
   byId('mirrorEvidence').hidden=['online','live'].includes(catalog[state.ref].kind);
   byId('mirrorEvidence').textContent=mirrorEvidence?'Hide desk copy':'View on desk';
   byId('mirrorEvidence').setAttribute('aria-pressed',String(mirrorEvidence));
 }
 byId('prev').disabled=state.index===0;byId('next').disabled=state.index===deck.length-1;
 byId('counter').textContent='Slide '+(state.index+1)+' of '+deck.length;
 byId('resume').hidden=!state.trail.length;
 byId('notesTab').setAttribute('aria-pressed',state.tab==='notes');
 byId('qaTab').setAttribute('aria-pressed',state.tab==='qa');
 byId('qaTab').hidden=!s.qa.length;
 if(s.cover)state.tab='notes';
 byId('notes').innerHTML=state.tab==='qa'?s.qa.map(q=>'<details class="question"><summary>'+safe(q.q)+'</summary><p>'+safe(q.a)+'</p></details>').join(''):'<ul class="cues">'+s.notes.map(n=>'<li>'+safe(n)+'</li>').join('')+'</ul>';
 const refs=[...new Set([...(s.image?[s.image]:[]),...s.sources])];
 const links=slideLinks(s);
 byId('sources').classList.toggle('section-sources',[2,3,4].includes(s.section));
 byId('sources').innerHTML=refs.map(sourceLink).join('')+links.map(externalLink).join('');
 const quick=[permissionsRef,...quickRefs].filter(ref=>!refs.includes(ref)).map(sourceLink);
 byId('quickSources').innerHTML=s.extras?'':'<h3>Quick access</h3>'+quick.join('');
 renderSlideCommands(s);
 save();transmit();tick();
}
byId('welcomeBtn').onclick=()=>go(0,true);
byId('extrasBtn').onclick=()=>go(deck.length-1,true);
byId('playClip').onclick=()=>controlClip('play');
byId('pauseClip').onclick=()=>controlClip('pause');
byId('outline').onclick=e=>{const b=e.target.closest('[data-slide]');if(b)go(Number(b.dataset.slide),true);};
document.querySelector('.sourcebox').onclick=e=>{
 const b=e.target.closest('[data-ref]');
 if(b)showRef(b.dataset.ref);
 if(e.target.closest('[data-commands]'))openCommands();
 handleCopy(e);
};
byId('commandFinder').onclick=handleCopy;
byId('dismissEvidence').onclick=closeRef;
byId('evidencePending').onclick=()=>{if(openAudience(true)){transmit();updateAudience();}};
byId('pageUp').onclick=()=>pageEvidence(-1);
byId('pageDown').onclick=()=>pageEvidence(1);
byId('mirrorEvidence').onclick=()=>{mirrorEvidence=!mirrorEvidence;render();};
byId('prev').onclick=()=>go(state.index-1);byId('next').onclick=()=>go(state.index+1);
byId('resume').onclick=previousTopic;
byId('notesTab').onclick=()=>{state.tab='notes';render();};byId('qaTab').onclick=()=>{state.tab='qa';render();};
const finder=byId('finder'), query=byId('query');
function freeText(x){return String(x).toLowerCase().normalize('NFKD').replace(/[’‘]/g,"'");}
function hits(){
 const q=freeText(query.value.trim()), result=[];
 if(mode==='all') deck.forEach((s,i)=>{
   const searchTerms=[s.title,s.short,s.kicker,s.lead,...s.notes,s.architecture?.label,
     ...s.points.flatMap(point=>[point.label,point.text]),
     ...s.workflow?.flatMap(step=>[step.label,step.text])||[],
     ...s.comparison?.flatMap(item=>[item.label,item.example,item.package,item.http,...item.details])||[],
     s.verification?.label,s.verification?.correlation,...(s.flow||[]),
     ...s.panels?.flatMap(panel=>[panel.label,panel.text,...(panel.items||[])])||[],
     ...s.matrix?.rows.flat()||[],s.context,s.callout?.label,s.callout?.text,
     ...s.timeline?.flatMap(stage=>[stage.time,stage.label,stage.text])||[],...(s.validation||[]),
     s.matrix?.scope,s.stepLabel,...(s.steps||[]),...(s.criteria||[]),
     ...s.extras?.map(item=>item.group+' '+item.label+' '+item.text)||[]];
   if(freeText(searchTerms.join(' ')).includes(q))
     result.push({text:s.title,meta:(SECTIONS[s.section]?.name || s.short)+' · slide '+(i+1),i});
   if(q)s.qa.forEach((qa,k)=>{if(freeText(qa.q+' '+qa.a).includes(q))result.push({text:qa.q,meta:'Panel Q&A · '+s.short,i,k});});
 });
 if(mode==='library'||q)Object.entries(catalog).forEach(([path,ref])=>{
   if(freeText(ref.title+' '+path).includes(q))result.push({text:shortTitle(path),meta:ref.kind==='live'?'Live site · '+ref.url:'Reference · '+path,ref:path});
 });
 return result;
}
let visible=[];
function list(){visible=hits();byId('results').innerHTML=visible.length?visible.map((h,n)=>'<button class="hit" data-hit="'+n+'">'+safe(h.text)+'<small>'+safe(h.meta)+'</small></button>').join(''):'<p>No matching topics. Try “401”, “readiness” or “Firewall”.</p>';}
function openFinder(kind){mode=kind;byId('finderTitle').textContent=kind==='library'?'Reference library':'Find a topic';query.value='';list();finder.showModal();query.focus();}
function choose(h){if(!h)return;finder.close();if(h.ref){showRef(h.ref);return;}
 go(h.i,true,h.k!=null?'qa':'notes');if(h.k!=null){const item=byId('notes').querySelectorAll('details')[h.k];if(item)item.open=true;}
}
byId('searchBtn').onclick=()=>openFinder('all');byId('libraryBtn').onclick=()=>openFinder('library');
byId('closeFinder').onclick=()=>finder.close();query.oninput=list;
byId('results').onclick=e=>{const b=e.target.closest('[data-hit]');if(b)choose(visible[Number(b.dataset.hit)]);};
query.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();choose(visible[0]);}if(e.key==='ArrowDown'){e.preventDefault();byId('results').querySelector('button')?.focus();}};
function tick(){
 const elapsed=state.elapsed+(state.started?Math.max(0,Date.now()-state.started):0);
 const seconds=Math.floor(elapsed/1000);
 const slide=deck[state.index];
 const index=slide.welcome?0:slide.section;
 const section=SECTIONS[index];
 const progress=byId('interviewProgress');
 byId('time').textContent=formatTime(seconds);
 progress.max=interviewDuration;
 progress.value=Math.min(seconds,interviewDuration);
 progress.setAttribute('aria-valuetext',formatTime(seconds)+' of '+formatTime(interviewDuration));
 byId('start').textContent=state.started?'Pause':elapsed?'Resume':'Start';
 const scheduled=SECTIONS.findIndex(item=>seconds<item.end);
 let pace, tone, remaining, target, detail;
 if(!section){
   remaining='Untimed';
   pace=seconds>=interviewDuration?'Interview time reached':'Optional discussion';
   tone=seconds>=interviewDuration?'over':'neutral';
   target=seconds>=interviewDuration?'Wrap up':'Wrap at '+formatTime(interviewDuration);
   detail=seconds>=interviewDuration?formatTime(seconds-interviewDuration)+' past the interview target':formatTime(interviewDuration-seconds)+' left in the interview';
 }else{
   const left=section.end-seconds;
   const next=SECTIONS[index+1];
   remaining=formatTime(Math.min(left,section.duration))+' left in section';
   target=(next?'Transition at ':'Wrap at ')+formatTime(section.end);
   detail=next?next.name:'Optional extras if time allows';
   if(seconds<section.start){
     pace='Ahead by '+formatTime(section.start-seconds);
     tone='ahead';
   }else if(left<=0){
     pace=left===0?'Transition due':'Behind by '+formatTime(-left);
     tone='over';
     target=scheduled<0?'Wrap up now':SECTIONS[scheduled].name;
     detail=scheduled<0?'60:00 interview target reached':'Scheduled now · since '+formatTime(SECTIONS[scheduled].start);
   }else if(!state.started&&!elapsed){
     pace='Clock ready';
     tone='neutral';
   }else{
     pace=left<=45?'Transition soon':'On schedule';
     tone=left<=45?'soon':'on';
   }
 }
 byId('activeSection').textContent=section?sectionNumber(index)+' · '+section.name:'Optional extras';
 byId('sectionAllocation').textContent=section?formatTime(section.duration)+' allocated · '+sectionWindow(section):'Outside the timed agenda';
 byId('sectionRemaining').textContent=remaining;
 const status=byId('paceStatus');
 status.textContent=pace;
 status.dataset.tone=tone;
 byId('transitionTarget').textContent=target;
 byId('transitionDetail').textContent=detail;
 updateAudience();
}
byId('start').onclick=()=>{if(state.started){state.elapsed+=Date.now()-state.started;state.started=0;}else state.started=Date.now();save();tick();};
byId('reset').onclick=()=>{state.elapsed=0;state.started=0;save();tick();};
function handleShortcuts(e){if(e.metaKey||e.altKey||e.ctrlKey||finder.open||byId('commandFinder').open||e.target.matches('input,textarea,select'))return;
 if(e.key==='ArrowRight'){e.preventDefault();go(state.index+1);}
 else if(e.key==='ArrowLeft'){e.preventDefault();go(state.index-1);}
 else if(e.key==='/'){e.preventDefault();openFinder('all');}
 else if(e.key==='Escape'&&state.ref)closeRef();
}
document.addEventListener('keydown',handleShortcuts);
const commands=window.COMMANDS;
const commandDialog=byId('commandFinder');
const commandQuery=byId('commandQuery');
const commandSection=byId('commandSection');
const lastSlideBySection=SECTIONS.map((_,section)=>deck.findLastIndex(slide=>slide.section===section));
commandSection.innerHTML='<option value="">All sections</option>'+SECTIONS.map((section,i)=>
 '<option value="'+i+'">'+sectionNumber(i)+' · '+safe(section.name)+'</option>'
).join('');

function shellPath(path){
 return "'"+decodeURIComponent(new URL(path,location.href).pathname).replace(/'/g,"'\\''")+"'";
}
function commandText(item){
 return item.command
   .replace('{{liveDemo}}',()=>shellPath('live-demo'))
   .replace('{{cliFile}}',()=>shellPath('live-demo/activitypulse/cli.js'));
}
function commandCard(item,expanded){
 const label=safe(item.title);
 return '<article class="command-card"><header><strong>'+label+'</strong><button type="button" class="copy-command" data-copy="'+commands.indexOf(item)+'" aria-label="Copy '+label+'">Copy</button></header>'+
   '<p><span class="command-kind">'+safe(item.kind)+'</span> '+safe(item.note)+'</p>'+
   '<details'+(expanded?' open':'')+'><summary>Show command</summary><pre><code>'+safe(commandText(item))+'</code></pre></details></article>';
}
function sectionCommands(index){return commands.filter(item=>item.sections.includes(index));}
function renderSlideCommands(slide){
 const index=slide.welcome?0:slide.section;
 const relevant=sectionCommands(index).filter(item=>item.slides.includes(slide.short));
 const section=sectionCommands(index);
 const final=state.index===lastSlideBySection[index];
 const summary=final?'Section command checklist':'Commands for this section';
 const panel=byId('slideCommands');
 panel.innerHTML=(relevant.length && !final
   ? '<h3>Commands for this slide</h3><div class="command-stack">'+relevant.map(item=>commandCard(item,false)).join('')+'</div>' : '')+
   (section.length
   ? '<details class="section-commands"'+(final?' open':'')+'><summary>'+summary+' <span>'+section.length+'</span></summary>'+
       '<div class="command-stack">'+section.map(item=>commandCard(item,false)).join('')+'</div></details>' : '');
}
function renderCommandResults(){
 const filter=commandSection.value;
 const terms=freeText(commandQuery.value.trim()).split(/\s+/).filter(Boolean);
 const matches=commands.filter(item=>{
   if(filter!=='' && !item.sections.includes(Number(filter)))return false;
   const text=freeText([item.title,item.note,item.kind,commandText(item),...item.slides,...item.sections.map(i=>SECTIONS[i].name)].join(' '));
   return terms.every(term=>text.includes(term));
 });
 byId('commandResults').innerHTML=matches.length
   ? '<p class="command-count">'+matches.length+(matches.length===1?' command':' commands')+'</p>'+matches.map(item=>commandCard(item,true)).join('')
   : '<p>No commands match. Try “report”, “Firewall” or “picocolors”.</p>';
}
function openCommands(){
 commandQuery.value='';
 commandSection.value='';
 renderCommandResults();
 commandDialog.showModal();
 commandQuery.focus();
}
function fallbackCopy(value){
 const field=document.createElement('textarea');
 field.value=value;
 field.setAttribute('readonly','');
 field.style.cssText='position:fixed;left:-9999px;top:0';
 (commandDialog.open?commandDialog:document.body).append(field);
 field.select();
 try{return document.execCommand('copy');}
 catch{return false;}
 finally{field.remove();}
}
async function handleCopy(event){
 const button=event.target.closest('[data-copy]');
 if(!button)return;
 const item=commands[Number(button.dataset.copy)];
 const value=commandText(item);
 let copied=false;
 if(navigator.clipboard){
   try{await navigator.clipboard.writeText(value);copied=true;}catch{}
 }
 if(!copied)copied=fallbackCopy(value);
 button.focus({preventScroll:true});
 if(!copied){
   const details=button.closest('.command-card').querySelector('details');
   details.open=true;
   const range=document.createRange();
   range.selectNodeContents(details.querySelector('code'));
   const selection=window.getSelection();
   selection.removeAllRanges();
   selection.addRange(range);
 }
 button.textContent=copied?'Copied':'Press ⌘C';
 byId('copyStatus').textContent=copied?'Copied '+item.title:'Command selected. Press Command C to copy.';
 setTimeout(()=>{button.textContent='Copy';},2200);
}
byId('closeCommands').onclick=()=>commandDialog.close();
commandQuery.oninput=renderCommandResults;
commandSection.onchange=renderCommandResults;

render();tick();setInterval(tick,800);
