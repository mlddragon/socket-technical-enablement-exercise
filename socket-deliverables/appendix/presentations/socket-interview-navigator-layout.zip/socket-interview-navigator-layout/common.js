'use strict';
const audienceProtocol=8;
const agenda = [
  {name:'Friction Log', duration:400, theme:0,
   note:'Start the interview clock on Welcome. Introductions count toward this section. Use first login and token scopes to discuss documentation, onboarding, and how you would mentor a new SE.',
   source:'friction-log.md'},
  {name:'Part I — Getting Familiar with Socket', duration:400, theme:4,
   note:"We've established the onboarding prerequisites and identified ways to improve first use. Now let's put those prerequisites into practice by configuring Socket and running the first scan.",
   source:'part-i-briefing.md'},
  {name:'Part II — Moving Upstream', duration:400, theme:5,
   note:"We've looked at how Socket evaluates dependencies within the development workflow. Now let's look at how Firewall provides protection at the point of installation.",
   followUp:'Allow 0:20 for the Part II introduction before opening Setup and configuration.',
   source:'part-ii-firewall-results.md'},
  {name:'Teach It Back', duration:1200, theme:1,
   note:"Having worked through those technologies myself, I now want to show you how I'd prepare a new Socket SE to take that knowledge into a customer conversation.",
   followUp:'Introduce Courtney and Widgets Mfg. Ask the panel to take the customer role as you compare the same change across both integrations.',
   source:'part-iii-talk-track.md'},
  {name:'Lab & Readiness', duration:600, theme:2,
   note:'After teaching the workflow decision, show how a learner practices it, uses the customer talk track, and demonstrates readiness. Keep the five-minute in-lab check distinct from the proposed field assessment.',
   followUp:'Allow 0:20 for the introduction. Frame the section as focused practice, a field job aid, observed demo readiness, and integrated field readiness.',
   source:'part-iii-lab.md'},
  {name:'Live Change', duration:600, theme:3,
   note:'Move from developing and assessing technical competency to demonstrating the work live. Ask what the panel would like to change or see and agree on the observable result before opening the demo.',
   source:'part-ii-firewall-results.md'}
];
let sectionBoundary=0;
const SECTIONS=agenda.map(section=>{
  const start=sectionBoundary;
  sectionBoundary+=section.duration;
  return {...section,start,end:sectionBoundary};
});
const interviewDuration=sectionBoundary;
function formatTime(seconds){
  const total=Math.max(0,Math.floor(seconds));
  return String(Math.floor(total/60)).padStart(2,'0')+':'+String(total%60).padStart(2,'0');
}
function sectionNumber(index){return String(index+1).padStart(2,'0');}
function sectionWindow(section){return formatTime(section.start)+'–'+formatTime(section.end);}
const welcome = {
  welcome:true, cover:true, section:null, title:'Technical Enablement Lead', short:'Welcome',
  kicker:'Welcome', lead:'Peer interview', points:[], qa:[], sources:[],
  notes:[
    'Welcome the panel and start the interview clock. Introductions count toward Friction Log.',
    'Preview the arc: what I encountered learning Socket, what I verified firsthand, how I would teach it to a new SE, and how I would develop and assess field readiness.'
  ]
};
const deck = [welcome, ...SECTIONS.flatMap((section, i) => {
  const topics = window.SLIDES.filter(slide => slide.section === i);
  const title = {cover:true, section:i, title:section.name, short:section.name,
    kicker:'Section opening', lead:'', points:[], notes:[section.note,...(section.followUp?[section.followUp]:[])],
    qa:[], sources:['socket-deliverables/' + section.source]};
  return [title, ...topics];
}), ...window.SLIDES.filter(slide => slide.extras)];
const catalog=window.LIBRARY;
const githubExercise='https://github.com/mlddragon/socket-technical-enablement-exercise';
const githubSnapshot=githubExercise+'/blob/9abc3d6775da7c7881fab0d25b93d694fc06ee2a/';
const socketDashboard='https://socket.dev/dashboard';
const socketDocs='https://docs.socket.dev/docs/';
const dashboardLinks={
  'Organization Access': [
    {title:'Socket dashboard · Settings → API Tokens',url:socketDashboard},
    {title:'Socket API token guide',url:socketDocs+'api-keys'}
  ],
  'CLI Permissions': [
    {title:'Socket dashboard · Settings → API Tokens',url:socketDashboard},
    {title:'Socket scan commands and scopes',url:socketDocs+'socket-scan'}
  ],
  'Establishing baseline': [
    {title:'Baseline scan in Socket',url:socketDashboard+'/org/mason-dillon-interview/sbom/ea295308-005a-4aeb-87f4-f525861e2fb4'}
  ],
  '1:Applying Policy': [
    {title:'Socket dashboard · Settings → Security Policy',url:socketDashboard},
    {title:'Security Policy actions and defaults',url:socketDocs+'security-policy-default-enabled-alerts'}
  ],
  'Configure integration': [
    {title:'Integration comparison · Exercise PR #1',url:githubExercise+'/pull/1'},
    {title:'Socket dependency diff',url:socketDashboard+'/org/mason-dillon-interview/diff-scan/b7326217-a2c7-4130-84ae-026912813e8c?tab=dependencies'},
    {title:'Socket dashboard · Settings → Integrations',url:socketDashboard}
  ],
  '1:Full Experiment': [
    {title:'Socket dashboard · Settings → Security Policy',url:socketDashboard},
    {title:'Integration comparison · Exercise PR #1',url:githubExercise+'/pull/1'}
  ],
  'GitHub Actions': [
    {title:'Socket for GitHub Actions',url:socketDocs+'socket-for-github-actions'},
    {title:'Widgets CI · Actions secrets',url:'https://github.com/mlddragon/widgets-ci/settings/secrets/actions'}
  ],
  'Socket GitHub App': [
    {title:'Installed GitHub Apps',url:'https://github.com/settings/installations'},
    {title:'Socket Security GitHub App',url:'https://github.com/apps/socket-security'}
  ],
  'Troubleshooting & Enforcement': [
    {title:'Failed run · HTTP 401 and exit 3',url:githubExercise+'/actions/runs/44557864628/job/135678730253'},
    {title:'Successful rerun · streaming fallback',url:githubExercise+'/actions/runs/44557864628/job/135696762163'}
  ],
  'Hands-on Lab': [
    {title:'Socket dashboard · Settings → Integrations',url:socketDashboard}
  ]
};
function liveKey(url){return 'live:'+url;}
function slideLinks(slide){
  const defaultLinks=dashboardLinks[slide.section+':'+slide.short]||dashboardLinks[slide.short]||[];
  return [...defaultLinks,...(slide.links||[])];
}
for(const slide of deck){
  const links=[...slideLinks(slide),...(slide.extras||[]).filter(item=>item.url).map(item=>({url:item.url,title:item.label}))];
  for(const path of slide.sources){
    if(!catalog[path])links.push({url:githubSnapshot+path,title:path.split('/').pop()});
  }
  for(const link of links){
    if(link.url.startsWith('https:'))catalog[liveKey(link.url)]??={kind:'live',...link,title:link.url===socketDashboard?'Socket dashboard':link.title};
  }
}
const byId=id=>document.getElementById(id);
function safe(value){return String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function shortTitle(path){return (catalog[path]?.title || path.split('/').pop()).replace(/^Part III [·|] /,'');}
function routeView(route,label){
  const nodes=route.map((node,index)=>(index?'<span class="registry-arrow" aria-hidden="true">→</span>':'')+
    '<div class="registry-node"><strong>'+safe(node.label)+'</strong>'+(node.text?'<span>'+safe(node.text)+'</span>':'')+'</div>').join('');
  return '<div class="registry-route" role="group" aria-label="'+safe(label)+'">'+nodes+'</div>';
}
function architectureView(diagram){
  return '<figure class="registry-diagram"><figcaption>'+safe(diagram.label)+'</figcaption>'+
    routeView(diagram.route,'Package download path')+
    '<div class="registry-api"><span class="registry-arrow" aria-hidden="true">↕</span><div class="registry-node" aria-label="Socket Firewall communicates with the Socket API">'+
    '<strong>'+safe(diagram.api.label)+'</strong><span>'+safe(diagram.api.text)+'</span></div></div></figure>';
}
function comparisonView(slide,figure){
  const columns=slide.comparison.map(item=>{
    const details=item.details.map(line=>'<li>'+safe(line)+'</li>').join('');
    const headline=item.example?'<p class="verdict-example">'+safe(item.example)+'</p>'
      :'<div class="verdict-title"><strong>'+safe(item.package)+'</strong><span>'+safe(item.http)+'</span></div>';
    return '<section class="verdict '+safe(item.tone)+'"><h3>'+safe(item.label)+'</h3>'+headline+
      '<ul>'+details+'</ul></section>';
  }).join('');
  const proof=slide.verification;
  const results=proof.results?.map(result=>'<span>'+safe(result)+'</span>').join('');
  return '<div class="verdict-grid">'+columns+'</div><div class="verdict-proof'+(figure?'':' text-only')+'"><div><strong>'+safe(proof.label)+'</strong>'+
    (results?'<div class="proof-results">'+results+'</div>':'')+'<p>'+safe(proof.correlation)+'</p></div>'+figure+'</div>';
}
function teachingPanels(panels){
  const cards=panels.map(panel=>{
    const items=panel.items?.map(item=>'<li>'+safe(item)+'</li>').join('');
    return '<section class="point"><h3>'+safe(panel.label)+'</h3>'+
      (items?'<ul>'+items+'</ul>':'<p>'+safe(panel.text)+'</p>')+'</section>';
  }).join('');
  return '<div class="points teaching-points" style="--count:'+panels.length+'">'+cards+'</div>';
}
function matrixView(matrix){
  const headings=matrix.columns.map(column=>'<th scope="col">'+safe(column)+'</th>').join('');
  const rows=matrix.rows.map(([label,...entries])=>'<tr><th scope="row">'+safe(label)+'</th>'+
    entries.map(entry=>'<td>'+safe(entry)+'</td>').join('')+'</tr>').join('');
  return '<table class="teaching-matrix" aria-label="'+safe(matrix.label||'Socket integration comparison')+'"><thead><tr>'+headings+'</tr></thead><tbody>'+rows+
    '</tbody></table>'+(matrix.scope?'<p class="matrix-scope">'+safe(matrix.scope)+'</p>':'');
}
function timelineView(stages){
  const items=stages.map(stage=>'<li><span>'+safe(stage.time)+'</span><strong>'+safe(stage.label)+'</strong>'+
    (stage.text?'<p>'+safe(stage.text)+'</p>':'')+'</li>').join('');
  return '<ol class="lesson-timeline" aria-label="Activity timing" style="--count:'+stages.length+'">'+items+'</ol>';
}
function referenceImage(ref){
  return ref==='socket-deliverables/part-iii-talk-track.pdf'?'talk-track-display.png':catalog[ref].url;
}
function board(i,ref,interactive){
  if(ref && catalog[ref])return referenceView(ref);
  const s=deck[i], section=SECTIONS[s.section];
  if (s.welcome) {
    return '<article class="board cover welcome"><img class="cover-logo" src="brand/socket-wordmark.svg" alt="Socket">'
      + '<div class="welcome-heading"><div class="cover-meta">Welcome <span>/</span> Peer interview</div>'
      + '<h2>'+safe(s.title)+'</h2></div><div class="welcome-signature"><strong>Mason Dillon</strong>'
      + '<span>Tuesday, November 24, 2026 · 1–2 PM Eastern</span></div></article>';
  }
  if (s.extras) {
    const groups=new Map();
    for(const item of s.extras){
      if(item.commands&&!interactive)continue;
      if(!groups.has(item.group))groups.set(item.group,[]);
      groups.get(item.group).push(item);
    }
    const renderEntry=item=>{
      const label=safe(item.label);
      let target='<span class="extras-title">'+label+'</span>';
      if(interactive){
        target=item.commands
          ? '<button class="extras-title" type="button" data-commands>'+label+'</button>'
          : '<button class="extras-title" type="button" data-ref="'+safe(item.ref||liveKey(item.url))+'">'+label+'</button>';
      }
      return '<li>'+target+'<span class="extras-detail">'+safe(item.text)+'</span></li>';
    };
    const categories=[...groups].map(([group,items])=>'<section><h3>'+safe(group)+'</h3><ul class="extras-list">'+items.map(renderEntry).join('')+'</ul></section>').join('');
    return '<article class="board extras-board"><h2>'+safe(s.title)+'</h2><div class="extras-groups">'+categories+'</div></article>';
  }
  if (s.cover) {
    return '<article class="board cover section-cover s'+section.theme+'"><div class="cover-art" aria-hidden="true"><i></i><i></i><i></i><i></i></div>'
      + '<img class="cover-logo" src="brand/socket-wordmark.svg" alt="Socket">'
      + '<div class="cover-heading"><div class="cover-meta">Section '+sectionNumber(s.section)+' <span> / </span> '+formatTime(section.duration)+' <span> / </span> '+sectionWindow(section)+'</div>'
      + '<h2>'+safe(s.title)+'</h2></div><div class="cover-byline">Mason Dillon <span> / </span> Technical Enablement</div></article>';
  }
  if (s.workflow) {
    const rows=s.workflow.map(step=>'<li><strong>'+safe(step.label)+'</strong><span>'+safe(step.text)+'</span></li>').join('');
    return '<article class="board workflow-board s'+section.theme+'"><div class="slidehead"><span>'+safe(s.kicker)+'</span><b>'+sectionNumber(s.section)+' / '+sectionNumber(SECTIONS.length-1)+'</b></div><h2>'+safe(s.title)+'</h2><ol class="workflow-list">'+rows+'</ol></article>';
  }
  if (s.video) {
    const poster='media/courtney-call.jpg';
    const media=interactive
      ? '<img class="call-poster" src="'+poster+'" alt="Courtney on the Widgets Mfg call"><div class="clip-controls"><button id="playClip">Play to audience</button><button id="pauseClip">Pause</button><span id="clipStatus" role="status"></span></div>'
      : '<video id="callVideo" controls playsinline preload="metadata" poster="'+poster+'" aria-label="Courtney’s captioned customer call" src="'+safe(s.video)+'"></video><p id="clipNotice" role="status" hidden></p>';
    return '<article class="board call-slide s1"><div class="call-heading"><h2>'+safe(s.title)+'</h2></div>'+media+'</article>';
  }
  const points='<div class="points" style="--count:'+s.points.length+'">'+s.points.map(p=>'<div class="point"><strong>'+safe(p.label)+'</strong><p>'+safe(p.text)+'</p></div>').join('')+'</div>';
  const media=s.image && catalog[s.image];
  let figure='';
  if(media){
    const img='<img class="slidepic" src="'+safe(referenceImage(s.image))+'" alt="'+safe(s.imageAlt||media.title)+'">';
    figure=interactive?'<button class="figbtn" id="enlarge" data-ref="'+safe(s.image)+'" title="Show full-size evidence in the audience window">'+img+'<small>Enlarge evidence ↗</small></button>':img;
  }
  const lead=s.lead?'<p class="lead">'+safe(s.lead)+'</p>':'';
  let layout=media?'<div class="media-layout">'+points+figure+'</div>':points;
  if(s.architecture)layout=points+architectureView(s.architecture);
  if(s.comparison)layout=comparisonView(s,figure);
  if(s.panels)layout=teachingPanels(s.panels);
  if(s.panels&&media)layout='<div class="talk-track-layout">'+layout+figure+'</div>';
  if(s.flow)layout=routeView(s.flow.map(label=>({label})),s.flowLabel||'Integration flow')+layout;
  if(s.matrix)layout=matrixView(s.matrix)+layout;
  const context=s.context?'<p class="lesson-context">'+safe(s.context)+'</p>':'';
  const timeline=s.timeline?timelineView(s.timeline):'';
  if(s.timeline&&s.callout)layout+=context+timeline;
  else if(s.timeline)layout=timeline+layout+context;
  else if(s.context)layout=context+layout;
  if(s.callout)layout+='<div class="lesson-callout"><strong>'+safe(s.callout.label)+'</strong><p>'+safe(s.callout.text)+'</p></div>';
  if(s.validation){
    layout+='<div class="validation-path">'+routeView(s.validation.map(label=>({label})),'Proposed field validation')+'</div>';
  }
  if(s.steps)layout+='<div class="validation-path slide-steps"><h3>'+safe(s.stepLabel)+'</h3>'+routeView(s.steps.map(label=>({label})),s.stepLabel)+'</div>';
  if(s.criteria)layout+='<div class="lesson-callout slide-criteria"><strong>'+safe(s.stepLabel)+'</strong><ul>'+s.criteria.map(item=>'<li>'+safe(item)+'</li>').join('')+'</ul></div>';
  const variant=s.architecture?' registry-board':s.comparison?' verdict-board':'';
  const teaching=(s.panels||s.matrix||s.section===3||s.section===4)?' teaching-board'+(s.section===3&&s.flow?' developer-board':'')+(s.matrix?' decision-board':''):'';
  const compact=s.section===0||s.section===5?' concise-board':'';
  const lesson=s.section===4?' lesson-board'+(s.validation?' field-board':''):'';
  return '<article class="board s'+section.theme+variant+teaching+lesson+compact+'"><div class="slidehead"><span>'+safe(s.kicker)+'</span><b>'+sectionNumber(s.section)+' / '+String(SECTIONS.length).padStart(2,'0')+'</b></div><div class="slidebody"><h2>'+safe(s.title)+'</h2>'+lead+layout+'</div><div class="slidefoot"><span>Socket · Technical enablement</span><span>'+safe(section.name)+' / '+String(i+1).padStart(2,'0')+'</span></div></article>';
}
function referenceView(ref) {
  const item=catalog[ref], content=window.REF_TEXT[ref];
  if(content){
    const template=document.createElement('template');template.innerHTML=content;
    const base=new URL(item.url,location.href);
    template.content.querySelectorAll('img[src]').forEach(el=>{el.src=new URL(el.getAttribute('src'),base).href;});
    template.content.querySelectorAll('a').forEach(a=>{const span=document.createElement('span');span.className='reference-link';span.innerHTML=a.innerHTML;a.replaceWith(span);});
    return '<article class="reader" tabindex="0" aria-label="Projected reference"><div class="evidence-mast"><img src="brand/socket-wordmark.svg" alt="Socket"><span>Interview evidence</span></div>'+template.innerHTML+'</article>';
  }
  if(item.kind==='live')return '<article class="online-reference"><header><strong>'+safe(item.title)+'</strong><a href="'+safe(item.url)+'" target="_self">Open in audience window ↗</a></header></article>';
  if(item.kind==='online'){
    return '<article class="online-reference"><header><strong>'+safe(item.title)+'</strong><a href="'+safe(item.url)+'" target="_self">Open in Google Sheets ↗</a></header><iframe title="'+safe(item.title)+'" src="'+safe(item.url)+'"></iframe></article>';
  }
  if(item.kind==='video'){
    return '<div class="ref-stage"><video class="ref-img ref-video" controls playsinline preload="metadata" src="'+safe(item.url)+'" aria-label="'+safe(shortTitle(ref))+'"></video></div>';
  }
  const src=referenceImage(ref);
  return '<div class="ref-stage"><img class="ref-img" src="'+safe(src)+'" alt="'+safe(shortTitle(ref))+'"></div>';
}
